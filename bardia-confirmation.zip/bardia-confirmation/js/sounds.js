/**
 * Bardia Sound Engine — Web Audio API (HTML version)
 */
const SoundEngine = (() => {
  let ctx = null;
  let master = null;
  let dry = null;
  let convolver = null;
  let enabled = true;
  let unlocked = false;
  let volume = 0.55;

  function ensure() {
    if (ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume;
    master.connect(ctx.destination);
    dry = ctx.createGain();
    dry.gain.value = 0.85;
    dry.connect(master);
    convolver = ctx.createConvolver();
    convolver.buffer = makeImpulse(1.2, 2);
    const rev = ctx.createGain();
    rev.gain.value = 0.18;
    convolver.connect(rev);
    rev.connect(master);
  }

  function makeImpulse(duration, decay) {
    const rate = ctx.sampleRate;
    const len = Math.floor(rate * duration);
    const buf = ctx.createBuffer(2, len, rate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
    return buf;
  }

  function now() { return ctx ? ctx.currentTime : 0; }

  async function unlock() {
    ensure();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      try { await ctx.resume(); } catch (e) {}
    }
    unlocked = ctx.state === 'running';
  }

  function setEnabled(on) {
    enabled = on;
  }

  function isEnabled() { return enabled; }

  function tone(opts) {
    if (!enabled) return;
    ensure();
    if (!ctx || !dry) return;
    if (!unlocked && ctx.state !== 'running') return;

    const t0 = now() + (opts.delay || 0);
    const attack = opts.attack != null ? opts.attack : 0.015;
    const decay = opts.decay != null ? opts.decay : 0.06;
    const sustain = opts.sustain != null ? opts.sustain : 0.35;
    const release = opts.release != null ? opts.release : 0.12;
    const peak = opts.peak != null ? opts.peak : 0.65;
    const dur = Math.max(opts.dur || 0.12, attack + release);

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = opts.type || 'sine';
    osc.frequency.setValueAtTime(opts.freq, t0);
    if (opts.slideTo) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, opts.slideTo), t0 + dur);
    }
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(peak, t0 + attack);
    gain.gain.linearRampToValueAtTime(peak * sustain, t0 + attack + decay);
    gain.gain.setValueAtTime(peak * sustain, t0 + dur - release);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(dry);
    if (opts.reverb && convolver) {
      const send = ctx.createGain();
      send.gain.value = 0.4;
      gain.connect(send);
      send.connect(convolver);
    }
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  function play(step) {
    if (!enabled) return;
    switch (step) {
      case 'detect_chain':
        tone({ freq: 880, dur: 0.1, type: 'square', peak: 0.45, attack: 0.008 });
        tone({ freq: 1320, dur: 0.09, type: 'square', peak: 0.4, delay: 0.085 });
        break;
      case 'fetch_market':
        tone({ freq: 523.25, dur: 0.14, type: 'sine', peak: 0.5 });
        tone({ freq: 659.25, dur: 0.14, type: 'sine', peak: 0.45, delay: 0.11 });
        break;
      case 'fetch_security':
        tone({ freq: 196, dur: 0.2, type: 'triangle', peak: 0.55, reverb: true });
        tone({ freq: 294, dur: 0.16, type: 'triangle', peak: 0.4, delay: 0.13 });
        break;
      case 'fetch_whale':
        tone({ freq: 70, dur: 0.4, type: 'sine', slideTo: 48, peak: 0.7, attack: 0.04, release: 0.2, reverb: true });
        break;
      case 'news_sentiment':
        tone({ freq: 620, dur: 0.11, type: 'triangle', peak: 0.45 });
        tone({ freq: 780, dur: 0.11, type: 'triangle', peak: 0.4, delay: 0.09 });
        break;
      case 'calculate_scores':
        tone({ freq: 400, dur: 0.07, type: 'sawtooth', peak: 0.3 });
        tone({ freq: 500, dur: 0.07, type: 'sawtooth', peak: 0.28, delay: 0.055 });
        tone({ freq: 620, dur: 0.08, type: 'sawtooth', peak: 0.26, delay: 0.11 });
        break;
      case 'final_scoring':
        tone({ freq: 523.25, dur: 0.14, type: 'sine', peak: 0.5 });
        tone({ freq: 659.25, dur: 0.14, type: 'sine', peak: 0.48, delay: 0.12 });
        tone({ freq: 783.99, dur: 0.18, type: 'sine', peak: 0.45, delay: 0.24 });
        break;
      case 'generate_report':
      case 'success':
        tone({ freq: 523.25, dur: 0.14, type: 'sine', peak: 0.5, reverb: true });
        tone({ freq: 659.25, dur: 0.14, type: 'sine', peak: 0.48, delay: 0.13, reverb: true });
        tone({ freq: 783.99, dur: 0.14, type: 'sine', peak: 0.46, delay: 0.26, reverb: true });
        tone({ freq: 1046.5, dur: 0.38, type: 'sine', peak: 0.55, delay: 0.4, release: 0.22, reverb: true });
        break;
      case 'error':
        tone({ freq: 180, dur: 0.28, type: 'sawtooth', slideTo: 110, peak: 0.55, attack: 0.01 });
        break;
      case 'click':
        tone({ freq: 1200, dur: 0.04, type: 'square', peak: 0.2, attack: 0.005 });
        break;
    }
  }

  return { unlock, play, setEnabled, isEnabled };
})();
