/**
 * Bardia Confirmation — Real API Layer
 * DexScreener + GoPlus + RugCheck + News
 */

const API = {
  // ==================== DexScreener ====================
  async getTokenByAddress(address) {
    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${address}`);
    if (!res.ok) throw new Error(`DexScreener error: ${res.status}`);
    return res.json();
  },

  // ==================== GoPlus Security ====================
  chainIdMap: {
    ethereum: '1', bsc: '56', 'bnb chain': '56', polygon: '137',
    arbitrum: '42161', optimism: '10', avalanche: '43114', base: '8453',
  },

  async getGoPlusSecurity(address, chainId) {
    try {
      if (chainId === 'solana') {
        const res = await fetch(`https://api.gopluslabs.io/api/v1/solana/token_security?contract_addresses=${address}`);
        if (!res.ok) return null;
        const data = await res.json();
        return data?.result?.[address] || data?.result || null;
      }
      const cid = this.chainIdMap[chainId?.toLowerCase()] || '1';
      const res = await fetch(`https://api.gopluslabs.io/api/v1/token_security/${cid}?contract_addresses=${address}`);
      if (!res.ok) return null;
      const data = await res.json();
      const key = Object.keys(data?.result || {}).find(k => k.toLowerCase() === address.toLowerCase());
      return key ? data.result[key] : null;
    } catch (e) {
      console.warn('GoPlus error:', e);
      return null;
    }
  },

  normalizeGoPlus(raw) {
    if (!raw) return null;
    const isHoneypot = raw.is_honeypot === '1' || raw.is_honeypot === true;
    const canMint = raw.can_take_back_ownership === '1' || raw.mintable === '1' || raw.is_mintable === '1';
    const canFreeze = raw.transfer_pausable === '1' || raw.freezable === '1';
    const hasBlacklist = raw.is_blacklisted === '1' || raw.is_in_blacklist === '1';
    const ownerChangeBalance = raw.owner_change_balance === '1';
    const hiddenOwner = raw.hidden_owner === '1';
    const buyTax = parseFloat(raw.buy_tax || 0) * 100;
    const sellTax = parseFloat(raw.sell_tax || 0) * 100;
    const isOpenSource = raw.is_open_source === '1';
    const isProxy = raw.is_proxy === '1';

    let riskPoints = 0;
    if (isHoneypot) riskPoints += 40;
    if (canMint) riskPoints += 15;
    if (canFreeze) riskPoints += 12;
    if (hasBlacklist) riskPoints += 10;
    if (ownerChangeBalance) riskPoints += 10;
    if (hiddenOwner) riskPoints += 8;
    if (buyTax > 10 || sellTax > 10) riskPoints += 10;
    else if (buyTax > 5 || sellTax > 5) riskPoints += 5;
    if (!isOpenSource) riskPoints += 5;
    if (isProxy) riskPoints += 3;

    const securityScore = Math.max(0, 100 - riskPoints);

    return {
      source: 'GoPlus',
      isHoneypot, canMint, canFreeze, hasBlacklist, ownerChangeBalance, hiddenOwner,
      buyTax: isNaN(buyTax) ? null : Math.round(buyTax * 10) / 10,
      sellTax: isNaN(sellTax) ? null : Math.round(sellTax * 10) / 10,
      isOpenSource, isProxy,
      securityScore,
      risks: [
        isHoneypot && { level: 'danger', label: 'Honeypot Detected' },
        canMint && { level: 'warn', label: 'Mintable' },
        canFreeze && { level: 'warn', label: 'Freezable / Pausable' },
        hasBlacklist && { level: 'warn', label: 'Has Blacklist' },
        ownerChangeBalance && { level: 'warn', label: 'Owner Can Change Balance' },
        hiddenOwner && { level: 'warn', label: 'Hidden Owner' },
        (buyTax > 10 || sellTax > 10) && { level: 'danger', label: `High Tax (B${buyTax}% / S${sellTax}%)` },
        !isOpenSource && { level: 'info', label: 'Not Open Source' },
        isProxy && { level: 'info', label: 'Proxy Contract' },
      ].filter(Boolean),
    };
  },

  // ==================== RugCheck (Solana) ====================
  async getRugCheck(address) {
    try {
      const res = await fetch(`https://api.rugcheck.xyz/v1/tokens/${address}/report/summary`);
      if (res.ok) return res.json();
      const full = await fetch(`https://api.rugcheck.xyz/v1/tokens/${address}/report`);
      if (full.ok) return full.json();
      return null;
    } catch (e) {
      console.warn('RugCheck error:', e);
      return null;
    }
  },

  normalizeRugCheck(raw) {
    if (!raw) return null;
    const scoreNormalised = raw.score_normalised ?? raw.score ?? null;
    let securityScore = 50;
    if (typeof scoreNormalised === 'number') {
      securityScore = Math.max(0, Math.min(100, 100 - scoreNormalised));
    }
    return {
      source: 'RugCheck',
      securityScore: Math.round(securityScore),
      scoreRaw: scoreNormalised,
      lpLockedPct: raw.lpLockedPct ?? null,
      risks: (raw.risks || []).map(r => ({
        level: r.level === 'danger' ? 'danger' : r.level === 'warn' ? 'warn' : 'info',
        label: r.name || 'Risk',
        value: r.value || '',
        description: r.description || '',
      })),
    };
  },

  // ==================== News ====================
  async getLatestNews(limit = 8) {
    try {
      const res = await fetch('https://min-api.cryptocompare.com/data/v2/news/?lang=EN&categories=BTC,ETH,SOL,Blockchain,Trading');
      if (res.ok) {
        const data = await res.json();
        const items = (data.Data || []).slice(0, limit).map(item => ({
          title: item.title,
          source: item.source_info?.name || item.source || 'CryptoCompare',
          url: item.url || item.guid,
          publishedAt: item.published_on ? new Date(item.published_on * 1000).toISOString() : null,
          body: (item.body || '').slice(0, 180),
          sentiment: this.simpleSentiment(item.title + ' ' + (item.body || '')),
        }));
        if (items.length) return items;
      }
    } catch (e) {
      console.warn('News error:', e);
    }
    return [
      { title: 'Crypto markets watch macro and ETF flows', source: 'Sample', url: '#', publishedAt: new Date().toISOString(), body: 'Risk sentiment remains data-dependent.', sentiment: 'neutral' },
    ];
  },

  simpleSentiment(text) {
    const t = (text || '').toLowerCase();
    const bull = ['partnership','launch','approval','surge','rally','bullish','adoption','record','integrate','etf'];
    const bear = ['hack','exploit','ban','lawsuit','crash','bearish','delay','rug','scam','fraud','sec charges'];
    let score = 0;
    bull.forEach(w => { if (t.includes(w)) score++; });
    bear.forEach(w => { if (t.includes(w)) score--; });
    if (score > 0) return 'positive';
    if (score < 0) return 'negative';
    return 'neutral';
  },

  // ==================== Normalize Token ====================
  normalizeToken(dexData) {
    if (!dexData?.pairs?.length) return null;
    const pairs = [...dexData.pairs].sort((a, b) => parseFloat(b.liquidity?.usd || 0) - parseFloat(a.liquidity?.usd || 0));
    const best = pairs[0];
    return {
      address: best.baseToken?.address || '',
      symbol: best.baseToken?.symbol || '???',
      name: best.baseToken?.name || 'Unknown',
      chain: best.chainId || 'unknown',
      dex: best.dexId || '',
      pairAddress: best.pairAddress || '',
      priceUsd: parseFloat(best.priceUsd || 0),
      priceChange24h: best.priceChange?.h24 ?? 0,
      liquidityUsd: parseFloat(best.liquidity?.usd || 0),
      volume24h: parseFloat(best.volume?.h24 || 0),
      fdv: parseFloat(best.fdv || best.marketCap || 0),
      marketCap: parseFloat(best.marketCap || best.fdv || 0),
      txns24h: (best.txns?.h24?.buys || 0) + (best.txns?.h24?.sells || 0),
      buys24h: best.txns?.h24?.buys || 0,
      sells24h: best.txns?.h24?.sells || 0,
      pairCreatedAt: best.pairCreatedAt || null,
      url: best.url || `https://dexscreener.com/${best.chainId}/${best.pairAddress}`,
      imageUrl: best.info?.imageUrl || null,
      allPairs: pairs.slice(0, 5).map(p => ({
        dex: p.dexId, liquidity: parseFloat(p.liquidity?.usd || 0),
        volume24h: parseFloat(p.volume?.h24 || 0),
      })),
    };
  },

  // ==================== Scoring ====================
  calculateScores(token, security = null) {
    if (!token) return null;

    let liquidityScore = 20;
    if (token.liquidityUsd > 5e6) liquidityScore = 95;
    else if (token.liquidityUsd > 1e6) liquidityScore = 85;
    else if (token.liquidityUsd > 250000) liquidityScore = 70;
    else if (token.liquidityUsd > 50000) liquidityScore = 50;
    else if (token.liquidityUsd > 10000) liquidityScore = 30;

    let activityScore = 20;
    if (token.volume24h > 1e7) activityScore = 95;
    else if (token.volume24h > 2e6) activityScore = 80;
    else if (token.volume24h > 5e5) activityScore = 65;
    else if (token.volume24h > 1e5) activityScore = 45;
    else if (token.volume24h > 2e4) activityScore = 30;

    let momentumScore = 50;
    const ch = token.priceChange24h;
    if (ch > 50) momentumScore = 90;
    else if (ch > 20) momentumScore = 80;
    else if (ch > 5) momentumScore = 65;
    else if (ch > 0) momentumScore = 55;
    else if (ch > -10) momentumScore = 40;
    else if (ch > -30) momentumScore = 25;
    else momentumScore = 10;

    const totalTx = token.buys24h + token.sells24h;
    let buyPressure = totalTx > 0 ? Math.round((token.buys24h / totalTx) * 100) : 50;

    let ageScore = 60;
    if (token.pairCreatedAt) {
      const h = (Date.now() - token.pairCreatedAt) / 36e5;
      if (h < 24) ageScore = 25;
      else if (h < 72) ageScore = 40;
      else if (h < 168) ageScore = 55;
      else if (h < 720) ageScore = 70;
      else ageScore = 85;
    }

    const securityScore = security?.securityScore ?? 50;

    const final = liquidityScore * 0.22 + activityScore * 0.18 + momentumScore * 0.14
      + buyPressure * 0.12 + ageScore * 0.12 + securityScore * 0.22;
    const clamped = Math.max(0, Math.min(100, final));

    let verdict = 'RISKY';
    if (clamped >= 80) verdict = 'STRONG BUY';
    else if (clamped >= 65) verdict = 'BUY';
    else if (clamped >= 45) verdict = 'NEUTRAL';
    else if (clamped >= 30) verdict = 'CAUTION';

    return {
      final: Math.round(clamped * 10) / 10,
      verdict,
      liquidity: Math.round(liquidityScore),
      activity: Math.round(activityScore),
      momentum: Math.round(momentumScore),
      buyPressure: Math.round(buyPressure),
      age: Math.round(ageScore),
      security: Math.round(securityScore),
    };
  },

  // ==================== Formatters ====================
  formatPrice(p) {
    if (!p) return '$0.00';
    if (p < 1e-6) return `$${p.toExponential(2)}`;
    if (p < 0.01) return `$${p.toFixed(8)}`;
    if (p < 1) return `$${p.toFixed(6)}`;
    if (p < 1000) return `$${p.toFixed(4)}`;
    return `$${p.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
  },
  formatUsd(n) {
    if (!n) return '$0';
    if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
    if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
    if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
    return `$${n.toFixed(0)}`;
  },
  formatPercent(n) {
    if (n == null) return '—';
    return `${n > 0 ? '+' : ''}${n.toFixed(2)}%`;
  },
  chainLabel(id) {
    const m = { solana: 'Solana', ethereum: 'Ethereum', base: 'Base', bsc: 'BNB Chain', arbitrum: 'Arbitrum', polygon: 'Polygon', avalanche: 'Avalanche', optimism: 'Optimism' };
    return m[id?.toLowerCase()] || id || 'Unknown';
  },
};
