'use client';

import Link from 'next/link';
import { useSession } from '@/lib/session';

export default function Navbar() {
  const { user, loading, logout } = useSession();

  return (
    <nav className="sticky top-0 z-50 glass border-b border-white/5">
      <div className="max-w-[1600px] mx-auto px-4 h-14 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-violet-600 flex items-center justify-center">
            <span className="font-orbitron font-bold text-xs text-black">B</span>
          </div>
          <span className="font-orbitron font-bold text-sm text-cyber-blue hidden sm:inline">
            BARDIA
          </span>
        </Link>

        <div className="flex items-center gap-3 text-sm">
          <Link href="/dashboard" className="text-gray-400 hover:text-cyber-blue transition">
            Terminal
          </Link>
          <Link href="/watchlist" className="text-gray-400 hover:text-cyber-blue transition">
            Watchlist
          </Link>
          <Link href="/history" className="text-gray-400 hover:text-cyber-blue transition hidden sm:inline">
            History
          </Link>
          <Link href="/profile" className="text-gray-400 hover:text-cyber-blue transition hidden sm:inline">
            Profile
          </Link>

          {!loading && !user && (
            <>
              <Link href="/login" className="text-gray-400 hover:text-cyber-blue transition">
                Login
              </Link>
              <Link
                href="/register"
                className="btn-primary px-4 py-1.5 rounded-lg text-xs"
              >
                Sign up
              </Link>
            </>
          )}

          {!loading && user && (
            <div className="flex items-center gap-3">
              <Link href="/profile" className="text-xs text-gray-500 hidden sm:inline hover:text-cyber-blue transition">
                {user.username || user.email}
                <span className="ml-1 badge badge-blue">{user.plan}</span>
              </Link>
              <button
                onClick={logout}
                className="text-xs text-gray-400 hover:text-cyber-red transition"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
