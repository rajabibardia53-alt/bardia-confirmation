# BARDIA CONFIRMATION — Next.js

Institutional-grade memecoin & smart money research terminal.

## Features

| Module | Status |
|--------|--------|
| DexScreener market data | Live |
| GoPlus + RugCheck security | Live |
| Whale heuristic signals | Live |
| News (CryptoPanic / CryptoCompare) | Live |
| Sound engine (Web Audio v2) | Live |
| Auth (JWT + httpOnly cookie) | Ready |
| PostgreSQL schema + helpers | Ready |
| Nansen / Arkham | Enterprise stubs (need paid keys) |

## Quick Start

```bash
cd nextjs
npm install
cp .env.example .env.local
# edit .env.local
npm run dev
```

## Environment

```env
JWT_SECRET=long-random-string
DATABASE_URL=postgresql://user:pass@localhost:5432/bardia
NEXT_PUBLIC_CRYPTOPANIC_TOKEN=
NANSEN_API_KEY=
ARKHAM_API_KEY=
```

## Database

```bash
psql $DATABASE_URL -f schema.sql
```

Tables: users, wallets, watchlists, analysis_history, trades, alerts, news_cache, token_scores

## Auth API

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/register | { email, password, username? } |
| POST | /api/auth/login | { email, password } |
| POST | /api/auth/logout | clear session cookie |
| GET | /api/auth/me | current user or 401 |

## Smart Money (Enterprise)

Nansen and Arkham require paid enterprise contracts. Keys must stay server-side.

| Path | Env |
|------|-----|
| GET /api/smartmoney/nansen?address=&chain= | NANSEN_API_KEY |
| GET /api/smartmoney/arkham?address=&chain= | ARKHAM_API_KEY |

Wire real endpoints inside `lib/enterprise.ts` once you have API docs from the vendor.

Without keys, the dashboard still shows the free **heuristic whale module** (buy/sell pressure + vol/liquidity).

## Sound Engine v2

Optimized Web Audio:

- Singleton AudioContext + master / dry / reverb buses
- ADSR envelopes
- Convolver reverb (synthetic impulse)
- Voice limit (8) with stealing
- Unlock on first user gesture
- Per-step distinctive tones (chain, market, security, whale, news, score, success, error)

## Project Structure

```
app/
  page.tsx                 Landing
  dashboard/page.tsx       Terminal UI
  api/auth/*               Register / Login / Logout / Me
  api/smartmoney/*         Nansen / Arkham proxies
lib/
  api.ts                   Public market / security / news / scoring
  enterprise.ts            Nansen / Arkham stubs
  auth.ts                  JWT + password hashing
  db.ts                    Postgres helpers + schema
  sounds.ts                Web Audio engine v2
schema.sql                 Full SQL schema
```

## Notes

- Never put Nansen/Arkham keys in `NEXT_PUBLIC_*` variables.
- Auth works only when DATABASE_URL points to a live Postgres with schema applied.
- Not financial advice.
