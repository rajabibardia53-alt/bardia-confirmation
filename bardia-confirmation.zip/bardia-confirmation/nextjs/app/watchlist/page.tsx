'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import { useSession } from '@/lib/session';

type WatchItem = {
  id: number;
  token_address: string;
  chain: string;
  symbol: string | null;
  name: string | null;
  added_at: string;
};

export default function WatchlistPage() {
  const { user, loading: sessionLoading } = useSession();
  const [items, setItems] = useState<WatchItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (sessionLoading) return;
    if (!user) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const res = await fetch('/api/watchlist');
        if (!res.ok) {
          setError('Could not load watchlist');
          return;
        }
        const data = await res.json();
        setItems(data.items || []);
      } catch {
        setError('Network error');
      } finally {
        setLoading(false);
      }
    })();
  }, [user, sessionLoading]);

  async function remove(id: number) {
    const res = await fetch(`/api/watchlist?id=${id}`, { method: 'DELETE' });
    if (res.ok) {
      setItems((prev) => prev.filter((i) => i.id !== id));
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-10">
        <h1 className="font-orbitron text-2xl font-bold mb-2">Watchlist</h1>
        <p className="text-sm text-gray-500 mb-8">
          Tokens you saved from the terminal.
        </p>

        {!sessionLoading && !user && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="text-gray-400 mb-4">Sign in to use your personal watchlist.</p>
            <div className="flex justify-center gap-3">
              <Link href="/login" className="btn-primary px-5 py-2 rounded-lg text-sm">
                Login
              </Link>
              <Link href="/register" className="border border-white/10 px-5 py-2 rounded-lg text-sm text-gray-300">
                Sign up
              </Link>
            </div>
          </div>
        )}

        {loading && user && (
          <p className="text-sm text-gray-500">Loading...</p>
        )}

        {error && <p className="text-sm text-cyber-red">{error}</p>}

        {!loading && user && items.length === 0 && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="text-gray-400 mb-4">Your watchlist is empty.</p>
            <Link href="/dashboard" className="text-cyber-blue text-sm hover:underline">
              Open Terminal →
            </Link>
          </div>
        )}

        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className="glass rounded-xl p-4 flex items-center justify-between gap-4"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{item.symbol || '???'}</span>
                  <span className="badge badge-blue">{item.chain}</span>
                </div>
                <p className="text-xs text-gray-500 truncate mt-0.5">
                  {item.name || item.token_address}
                </p>
                <p className="text-[10px] text-gray-600 font-mono truncate">
                  {item.token_address}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Link
                  href={`/dashboard?address=${encodeURIComponent(item.token_address)}`}
                  className="text-xs text-cyber-blue hover:underline"
                >
                  Analyze
                </Link>
                <button
                  onClick={() => remove(item.id)}
                  className="text-xs text-gray-500 hover:text-cyber-red"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
