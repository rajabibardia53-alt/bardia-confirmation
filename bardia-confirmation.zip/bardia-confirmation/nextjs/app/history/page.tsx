'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import { useSession } from '@/lib/session';

type HistoryItem = {
  id: number;
  token_address: string;
  chain: string | null;
  final_score: number | string | null;
  verdict: string | null;
  preferred_llm: string | null;
  created_at: string;
  full_report?: any;
};

function verdictClass(v: string | null) {
  if (!v) return 'badge-gray';
  if (v.includes('BUY')) return 'badge-green';
  if (v === 'NEUTRAL') return 'badge-blue';
  if (v === 'CAUTION') return 'badge-gold';
  return 'badge-red';
}

export default function HistoryPage() {
  const { user, loading: sessionLoading } = useSession();
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState<number | null>(null);

  const load = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/history?limit=50');
      if (!res.ok) {
        setError('Could not load history');
        return;
      }
      const data = await res.json();
      setItems(data.items || []);
      setTotal(data.total || 0);
    } catch {
      setError('Network error');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (!sessionLoading) load();
  }, [sessionLoading, load]);

  async function remove(id: number) {
    const res = await fetch(`/api/history?id=${id}`, { method: 'DELETE' });
    if (res.ok) {
      setItems((prev) => prev.filter((i) => i.id !== id));
      setTotal((t) => Math.max(0, t - 1));
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-10">
        <div className="flex items-end justify-between gap-4 mb-8">
          <div>
            <h1 className="font-orbitron text-2xl font-bold mb-1">Analysis History</h1>
            <p className="text-sm text-gray-500">
              {user ? `${total} saved analyses` : 'Sign in to view your history'}
            </p>
          </div>
          <Link href="/dashboard" className="text-sm text-cyber-blue hover:underline">
            New analysis →
          </Link>
        </div>

        {!sessionLoading && !user && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="text-gray-400 mb-4">Your analyses are saved when you are logged in.</p>
            <div className="flex justify-center gap-3">
              <Link href="/login" className="btn-primary px-5 py-2 rounded-lg text-sm">Login</Link>
              <Link href="/register" className="border border-white/10 px-5 py-2 rounded-lg text-sm text-gray-300">
                Sign up
              </Link>
            </div>
          </div>
        )}

        {loading && user && <p className="text-sm text-gray-500">Loading...</p>}
        {error && <p className="text-sm text-cyber-red mb-4">{error}</p>}

        {!loading && user && items.length === 0 && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="text-gray-400 mb-4">No analyses yet.</p>
            <Link href="/dashboard" className="text-cyber-blue text-sm hover:underline">
              Open Terminal →
            </Link>
          </div>
        )}

        <div className="space-y-3">
          {items.map((item) => {
            const symbol =
              item.full_report?.token?.symbol ||
              item.token_address.slice(0, 6) + '…';
            const score = item.final_score != null ? Number(item.final_score) : null;
            const date = item.created_at
              ? new Date(item.created_at).toLocaleString()
              : '—';

            return (
              <div key={item.id} className="glass rounded-xl overflow-hidden">
                <div className="p-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold">{symbol}</span>
                      {item.chain && <span className="badge badge-blue">{item.chain}</span>}
                      {item.verdict && (
                        <span className={`badge ${verdictClass(item.verdict)}`}>
                          {item.verdict}
                        </span>
                      )}
                      {score != null && (
                        <span className="text-sm font-orbitron text-cyber-blue">
                          {score.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-gray-600 font-mono truncate mt-1 max-w-md">
                      {item.token_address}
                    </p>
                    <p className="text-[11px] text-gray-500 mt-0.5">{date}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Link
                      href={`/dashboard?address=${encodeURIComponent(item.token_address)}`}
                      className="text-xs text-cyber-blue hover:underline"
                    >
                      Re-analyze
                    </Link>
                    <button
                      onClick={() => setExpanded(expanded === item.id ? null : item.id)}
                      className="text-xs text-gray-400 hover:text-white"
                    >
                      {expanded === item.id ? 'Hide' : 'Details'}
                    </button>
                    <button
                      onClick={() => remove(item.id)}
                      className="text-xs text-gray-500 hover:text-cyber-red"
                    >
                      Delete
                    </button>
                  </div>
                </div>

                {expanded === item.id && (
                  <div className="px-4 pb-4 border-t border-white/5 pt-3 space-y-4">
                    {/* Token snapshot */}
                    {item.full_report?.token && (
                      <div>
                        <div className="text-[11px] text-gray-500 uppercase tracking-wider mb-2">Market snapshot</div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                          <div className="rounded-lg bg-white/5 p-2">
                            <div className="text-gray-500">Price</div>
                            <div className="font-semibold">${Number(item.full_report.token.priceUsd || 0).toPrecision(6)}</div>
                          </div>
                          <div className="rounded-lg bg-white/5 p-2">
                            <div className="text-gray-500">Liquidity</div>
                            <div className="font-semibold">
                              ${Number(item.full_report.token.liquidityUsd || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                            </div>
                          </div>
                          <div className="rounded-lg bg-white/5 p-2">
                            <div className="text-gray-500">24h Volume</div>
                            <div className="font-semibold">
                              ${Number(item.full_report.token.volume24h || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                            </div>
                          </div>
                          <div className="rounded-lg bg-white/5 p-2">
                            <div className="text-gray-500">24h Change</div>
                            <div className={`font-semibold ${Number(item.full_report.token.priceChange24h) >= 0 ? 'text-cyber-green' : 'text-cyber-red'}`}>
                              {Number(item.full_report.token.priceChange24h || 0).toFixed(2)}%
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Scores */}
                    {item.full_report?.scores && (
                      <div>
                        <div className="text-[11px] text-gray-500 uppercase tracking-wider mb-2">Score breakdown</div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                          {Object.entries(item.full_report.scores).map(([k, v]) => (
                            <div key={k} className="rounded-lg bg-white/5 p-2">
                              <div className="text-gray-500 capitalize">{k}</div>
                              <div className="font-semibold">{String(v)}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Security */}
                    {item.full_report?.security && (
                      <div>
                        <div className="text-[11px] text-gray-500 uppercase tracking-wider mb-2">
                          Security ({item.full_report.security.source || '—'})
                        </div>
                        <div className="text-xs text-gray-400 space-y-1">
                          <p>Score: {item.full_report.security.securityScore ?? '—'}/100</p>
                          {(item.full_report.security.risks || []).length === 0 ? (
                            <p className="text-cyber-green">No major risks stored</p>
                          ) : (
                            (item.full_report.security.risks || []).map((r: any, i: number) => (
                              <div key={i} className="flex gap-2">
                                <span className={
                                  r.level === 'danger' ? 'text-cyber-red' :
                                  r.level === 'warn' ? 'text-cyber-gold' : 'text-gray-500'
                                }>{r.level}</span>
                                <span>{r.label}{r.value ? ` — ${r.value}` : ''}</span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    )}

                    {/* Whale */}
                    {item.full_report?.whale && (
                      <div>
                        <div className="text-[11px] text-gray-500 uppercase tracking-wider mb-2">Whale / flow</div>
                        <p className="text-xs text-gray-400">
                          <span className="text-white capitalize">{item.full_report.whale.type}</span>
                          {' '}(strength {item.full_report.whale.strength})
                          {item.full_report.whale.buyRatio != null && ` · buy ratio ${item.full_report.whale.buyRatio}%`}
                          <br />
                          {item.full_report.whale.note}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
