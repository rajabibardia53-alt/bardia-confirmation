'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';

export default function LandingPage() {
  const [address, setAddress] = useState('');
  const router = useRouter();

  const go = () => {
    if (address.trim()) {
      router.push(`/dashboard?address=${encodeURIComponent(address.trim())}`);
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <div className="min-h-screen">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-400 to-violet-600 flex items-center justify-center">
              <span className="font-orbitron font-bold text-sm text-black">B</span>
            </div>
            <div>
              <span className="font-orbitron font-bold text-lg tracking-wider text-cyber-blue">BARDIA</span>
              <span className="font-orbitron text-xs text-cyber-gold ml-1">CONFIRMATION</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="text-sm text-gray-400 hover:text-cyber-blue transition">Terminal</Link>
            <Link href="/watchlist" className="text-sm text-gray-400 hover:text-cyber-blue transition">Watchlist</Link>
            <Link href="/login" className="text-sm text-gray-400 hover:text-cyber-blue transition">Login</Link>
            <a href="https://t.me/Br13881388" target="_blank" className="text-sm text-gray-400 hover:text-cyber-gold transition">Contact</a>
            <Link href="/dashboard" className="btn-primary text-sm px-5 py-2 rounded-lg">Launch Terminal</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center pt-16 cyber-grid">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="relative max-w-7xl mx-auto px-4 py-20 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass mb-8">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs font-medium text-cyber-gold tracking-wide">INSTITUTIONAL-GRADE RESEARCH TERMINAL</span>
          </div>

          <h1 className="font-orbitron text-5xl sm:text-6xl md:text-7xl font-black tracking-tight mb-6">
            BARDIA
            <span className="block mt-2 bg-gradient-to-r from-cyan-400 via-sky-300 to-yellow-400 bg-clip-text text-transparent">
              CONFIRMATION
            </span>
          </h1>

          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-2">
            We don&apos;t predict pumps.<br />
            <span className="text-cyber-blue font-medium">We confirm probability.</span>
          </p>
          <p className="text-sm text-gray-500 mb-10">
            Live market data · Security scan · Whale signals · News sentiment · Bardia Score
          </p>

          <div className="max-w-2xl mx-auto mb-8">
            <div className="glass rounded-2xl p-2">
              <div className="flex items-center gap-2">
                <input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && go()}
                  placeholder="Paste Contract Address (Solana / ETH / Base / BNB...)"
                  className="cyber-input flex-1 px-4 py-3 rounded-xl text-sm bg-transparent border-none focus:ring-0"
                />
                <button onClick={go} className="btn-primary shrink-0 px-6 py-3 rounded-xl text-sm">
                  Analyze
                </button>
              </div>
            </div>
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {['Solana', 'Ethereum', 'Base', 'BNB Chain'].map((c) => (
                <span key={c} className="px-3 py-1 rounded-full text-xs glass text-gray-500">{c}</span>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto mt-14">
            {[
              { v: 'Live', l: 'DexScreener' },
              { v: 'GoPlus', l: 'Security' },
              { v: 'Whale', l: 'Smart Money' },
              { v: '0-100', l: 'Bardia Score' },
            ].map((s) => (
              <div key={s.l} className="glass rounded-xl p-4">
                <div className="text-2xl font-orbitron font-bold text-cyber-blue">{s.v}</div>
                <div className="text-xs text-gray-500 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-violet-600 flex items-center justify-center">
              <span className="font-orbitron font-bold text-xs text-black">B</span>
            </div>
            <span className="font-orbitron font-bold text-sm">BARDIA CONFIRMATION</span>
          </div>
          <a href="https://t.me/Br13881388" target="_blank" className="text-sm text-gray-400 hover:text-cyber-gold">
            @Br13881388
          </a>
        </div>
        <p className="text-center text-xs text-gray-600 mt-6">© 2026 Bardia Confirmation. Not financial advice.</p>
      </footer>
    </div>
  );
}
