'use client';

import { useState, useEffect, useCallback, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  getTokenByAddress,
  normalizeToken,
  getGoPlusSecurity,
  normalizeGoPlus,
  getRugCheck,
  normalizeRugCheck,
  getCryptoPanicNews,
  analyzeWhaleActivity,
  calculateScores,
  formatPrice,
  formatUsd,
  chainLabel,
  type TokenData,
  type SecurityData,
  type Scores,
  type NewsItem,
  type WhaleSignal,
} from '@/lib/api';
import { soundEngine, type SoundStep } from '@/lib/sounds';
import Navbar from '@/components/Navbar';
import { useSession } from '@/lib/session';

function DashboardInner() {
  const searchParams = useSearchParams();
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [error, setError] = useState('');
  const [token, setToken] = useState<TokenData | null>(null);
  const [scores, setScores] = useState<Scores | null>(null);
  const [security, setSecurity] = useState<SecurityData | null>(null);
  const [whale, setWhale] = useState<WhaleSignal | null>(null);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [soundOn, setSoundOn] = useState(true);
  const [saveStatus, setSaveStatus] = useState('');
  const [watchStatus, setWatchStatus] = useState('');
  const { user } = useSession();

  const play = useCallback((step: SoundStep) => {
    if (soundOn && soundEngine) soundEngine.play(step);
  }, [soundOn]);

  const runAnalysis = useCallback(async (address: string) => {
    if (!address || address.length < 10) {
      setError('Please enter a valid contract address.');
      play('error');
      return;
    }

    soundEngine?.unlock();
    setLoading(true);
    setError('');
    setToken(null);
    setScores(null);
    setSecurity(null);
    setWhale(null);

    try {
      // 1. Market
      setLoadingStep('Fetching market data...');
      play('fetch_market');
      const raw = await getTokenByAddress(address.trim());
      const t = normalizeToken(raw);
      if (!t) {
        setError('No trading pairs found for this address.');
        play('error');
        setLoading(false);
        return;
      }
      setToken(t);
      play('detect_chain');

      // 2. Security
      setLoadingStep('Scanning security (GoPlus / RugCheck)...');
      play('fetch_security');
      let sec: SecurityData | null = null;
      if (t.chain === 'solana') {
        const rug = await getRugCheck(t.address);
        sec = normalizeRugCheck(rug);
        if (!sec) {
          const gp = await getGoPlusSecurity(t.address, 'solana');
          sec = normalizeGoPlus(gp);
        }
      } else {
        const gp = await getGoPlusSecurity(t.address, t.chain);
        sec = normalizeGoPlus(gp);
      }
      setSecurity(sec);

      // 3. Whale
      setLoadingStep('Analyzing whale & smart money flow...');
      play('fetch_whale');
      const w = analyzeWhaleActivity(t);
      setWhale(w);

      // 4. News
      setLoadingStep('Loading news & sentiment...');
      play('news_sentiment');
      const n = await getCryptoPanicNews('hot', t.symbol, 6);
      setNews(n);

      // 5. Score
      setLoadingStep('Computing Bardia Score...');
      play('calculate_scores');
      await new Promise((r) => setTimeout(r, 300));
      const s = calculateScores(t, sec);
      setScores(s);
      play('final_scoring');

      setLoadingStep('Report ready');
      play('generate_report');

      // Auto-save analysis (history if logged in + global token_scores cache)
      try {
        setSaveStatus('Saving...');
        const saveRes = await fetch('/api/analyze/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tokenAddress: t.address,
            chain: t.chain,
            finalScore: s.final,
            verdict: s.verdict,
            fullReport: { token: t, scores: s, security: sec, whale: w },
          }),
        });
        const saveData = await saveRes.json();
        if (saveRes.ok) {
          setSaveStatus(saveData.savedToHistory ? 'Saved to your history' : 'Cached (login to save history)');
        } else {
          setSaveStatus('Save skipped (DB offline)');
        }
      } catch {
        setSaveStatus('Save skipped');
      }
    } catch (e: any) {
      setError(e.message || 'Analysis failed');
      play('error');
    } finally {
      setLoading(false);
    }
  }, [play]);

  useEffect(() => {
    const prefill = searchParams.get('address');
    if (prefill) {
      setInput(prefill);
      runAnalysis(prefill);
    }
  }, [searchParams, runAnalysis]);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    soundEngine?.toggle(next);
    if (next) soundEngine?.unlock();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Search bar */}
      <div className="border-b border-white/5 bg-black/20">
        <div className="max-w-[1600px] mx-auto px-4 h-14 flex items-center gap-4">
          <div className="flex-1 max-w-xl">
            <div className="relative flex items-center">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && runAnalysis(input)}
                placeholder="Paste contract address..."
                className="cyber-input w-full pl-4 pr-24 py-2.5 rounded-xl text-sm"
              />
              <button
                onClick={() => runAnalysis(input)}
                disabled={loading}
                className="btn-primary absolute right-1.5 px-4 py-1.5 rounded-lg text-xs disabled:opacity-50"
              >
                {loading ? '...' : 'Analyze'}
              </button>
            </div>
          </div>
          <button
            onClick={toggleSound}
            className="w-9 h-9 rounded-lg border border-white/10 flex items-center justify-center text-gray-400 hover:text-cyber-blue transition"
            title={soundOn ? 'Mute sounds' : 'Enable sounds'}
          >
            {soundOn ? '🔊' : '🔇'}
          </button>
        </div>
      </div>
<main className="flex-1 max-w-[1400px] mx-auto w-full p-4 sm:p-6">
        {/* Empty */}
        {!loading && !token && !error && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <h2 className="font-orbitron text-2xl font-bold mb-2">Research Terminal</h2>
            <p className="text-gray-400 text-sm max-w-md">
              Paste a contract address for live market data, security scan, whale signals and news.
            </p>
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <div className="w-10 h-10 border-2 border-cyber-blue/30 border-t-cyber-blue rounded-full animate-spin mb-4" />
            <p className="font-orbitron text-sm text-cyber-blue mb-1">Analyzing...</p>
            <p className="text-xs text-gray-500">{loadingStep}</p>
          </div>
        )}

        {/* Error */}
        {error && !loading && (
          <div className="flex flex-col items-center justify-center min-h-[40vh] text-center">
            <p className="text-cyber-red font-semibold mb-2">Analysis Failed</p>
            <p className="text-sm text-gray-400">{error}</p>
          </div>
        )}

        {/* Results */}
        {token && scores && !loading && (
          <div className="space-y-6 animate-in fade-in">
            {/* Header */}
            <div className="glass rounded-2xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-cyan-400 to-violet-600 flex items-center justify-center font-orbitron font-bold text-black text-lg overflow-hidden">
                    {token.imageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={token.imageUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      token.symbol.slice(0, 2)
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h1 className="font-orbitron text-xl font-bold">{token.symbol}</h1>
                      <span className="badge badge-blue">{chainLabel(token.chain)}</span>
                      <span className="badge badge-gray">{token.dex}</span>
                      <button
                        onClick={async () => {
                          if (!user) { setWatchStatus('Login to use watchlist'); return; }
                          setWatchStatus('Adding...');
                          const res = await fetch('/api/watchlist', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              tokenAddress: token.address,
                              chain: token.chain,
                              symbol: token.symbol,
                              name: token.name,
                            }),
                          });
                          setWatchStatus(res.ok ? 'Added to watchlist' : 'Failed');
                        }}
                        className="text-xs px-2 py-0.5 rounded border border-white/10 text-gray-400 hover:text-cyber-gold hover:border-cyber-gold/40 transition"
                      >
                        + Watchlist
                      </button>
                      {watchStatus && <span className="text-[10px] text-gray-500">{watchStatus}</span>}
                      {saveStatus && <span className="text-[10px] text-gray-500">{saveStatus}</span>}
                    </div>
                    <p className="text-sm text-gray-400">{token.name}</p>
                    <p className="text-xs text-gray-600 font-mono mt-1 break-all">{token.address}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-orbitron text-2xl font-bold">{formatPrice(token.priceUsd)}</div>
                  <div className={`text-sm ${token.priceChange24h >= 0 ? 'text-cyber-green' : 'text-cyber-red'}`}>
                    {token.priceChange24h > 0 ? '+' : ''}{token.priceChange24h.toFixed(2)}% (24h)
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-5">
                {[
                  ['Market Cap', formatUsd(token.marketCap || token.fdv)],
                  ['FDV', formatUsd(token.fdv)],
                  ['Liquidity', formatUsd(token.liquidityUsd)],
                  ['24h Volume', formatUsd(token.volume24h)],
                  ['24h Txns', token.txns24h.toLocaleString()],
                  ['Buys / Sells', `${token.buys24h.toLocaleString()} / ${token.sells24h.toLocaleString()}`],
                ].map(([l, v]) => (
                  <div key={l as string} className="rounded-xl p-3 bg-white/5">
                    <div className="text-[11px] text-gray-500">{l}</div>
                    <div className="text-sm font-semibold mt-1">{v}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Score + Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="glass rounded-2xl p-6 flex flex-col items-center border border-yellow-500/20">
                <div className="text-xs text-gray-500 tracking-wider mb-3">BARDIA SCORE</div>
                <div className="font-orbitron text-5xl font-bold text-cyber-blue mb-2">{scores.final}</div>
                <span className={`badge text-sm px-4 py-1 ${
                  scores.verdict.includes('BUY') ? 'badge-green' :
                  scores.verdict === 'NEUTRAL' ? 'badge-blue' :
                  scores.verdict === 'CAUTION' ? 'badge-gold' : 'badge-red'
                }`}>{scores.verdict}</span>
              </div>
              <div className="lg:col-span-2 glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold mb-4">Score Breakdown</h3>
                <div className="space-y-3">
                  {[
                    ['Liquidity', scores.liquidity, 'bg-cyan-400'],
                    ['Activity', scores.activity, 'bg-cyan-400'],
                    ['Momentum', scores.momentum, 'bg-yellow-400'],
                    ['Buy Pressure', scores.buyPressure, 'bg-green-400'],
                    ['Security', scores.security, 'bg-green-400'],
                    ['Pair Age', scores.age, 'bg-violet-400'],
                  ].map(([label, val, color]) => (
                    <div key={label as string}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">{label}</span>
                        <span>{val as number}/100</span>
                      </div>
                      <div className="progress-bar">
                        <div className={`progress-fill ${color}`} style={{ width: `${val}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Security + Whale */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Security */}
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold">Security</h3>
                  <span className="text-xs text-gray-500">{security?.source || '—'}</span>
                </div>
                {security ? (
                  <>
                    <div className={`text-3xl font-orbitron font-bold mb-3 ${
                      scores.security >= 70 ? 'text-cyber-green' : scores.security >= 40 ? 'text-cyber-gold' : 'text-cyber-red'
                    }`}>{scores.security}/100</div>
                    {security.lpLockedPct != null && (
                      <p className="text-xs text-gray-500 mb-2">LP Locked: {security.lpLockedPct}%</p>
                    )}
                    <div className="space-y-1">
                      {(security.risks || []).length === 0 ? (
                        <p className="text-sm text-cyber-green">No major risks flagged</p>
                      ) : (
                        security.risks.map((r, i) => (
                          <div key={i} className="flex gap-2 text-sm py-1 border-b border-white/5 last:border-0">
                            <span className={`text-xs uppercase w-14 shrink-0 ${
                              r.level === 'danger' ? 'text-cyber-red' : r.level === 'warn' ? 'text-cyber-gold' : 'text-gray-500'
                            }`}>{r.level}</span>
                            <span>{r.label}{r.value ? ` — ${r.value}` : ''}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-gray-500">Security data unavailable for this token/chain.</p>
                )}
              </div>

              {/* Whale */}
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold">Whale / Smart Money</h3>
                  <span className="text-xs text-gray-500">Heuristic</span>
                </div>
                {whale ? (
                  <>
                    <div className="flex items-center gap-3 mb-3">
                      <span className={`badge text-sm px-3 py-1 ${
                        whale.type === 'accumulation' ? 'badge-green' :
                        whale.type === 'distribution' ? 'badge-red' : 'badge-gray'
                      }`}>{whale.type.toUpperCase()}</span>
                      <span className="text-2xl font-orbitron font-bold">{whale.strength}</span>
                    </div>
                    <p className="text-sm text-gray-400 mb-4">{whale.note}</p>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="rounded-lg bg-white/5 p-3">
                        <div className="text-xs text-gray-500">Buy Ratio</div>
                        <div className="font-semibold">{whale.buyRatio}%</div>
                      </div>
                      <div className="rounded-lg bg-white/5 p-3">
                        <div className="text-xs text-gray-500">Vol / Liquidity</div>
                        <div className="font-semibold">{whale.volumeToLiquidity}x</div>
                      </div>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-cyber-green">Buys</span>
                          <span>{token.buys24h.toLocaleString()}</span>
                        </div>
                        <div className="progress-bar">
                          <div className="progress-fill bg-green-400" style={{
                            width: `${(token.buys24h / (token.buys24h + token.sells24h || 1)) * 100}%`
                          }} />
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-cyber-red">Sells</span>
                          <span>{token.sells24h.toLocaleString()}</span>
                        </div>
                        <div className="progress-bar">
                          <div className="progress-fill bg-red-400" style={{
                            width: `${(token.sells24h / (token.buys24h + token.sells24h || 1)) * 100}%`
                          }} />
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-gray-500">—</p>
                )}
              </div>
            </div>

            {/* News */}
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold">News & Sentiment</h3>
                <span className="text-xs text-gray-500">
                  {process.env.NEXT_PUBLIC_CRYPTOPANIC_TOKEN ? 'CryptoPanic' : 'CryptoCompare'}
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {news.length === 0 && <p className="text-sm text-gray-500">No news loaded.</p>}
                {news.map((n, i) => (
                  <a key={i} href={n.url} target="_blank" rel="noreferrer"
                     className="block rounded-xl p-3 bg-white/5 hover:bg-white/10 transition">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`badge ${
                        n.sentiment === 'positive' ? 'badge-green' :
                        n.sentiment === 'negative' ? 'badge-red' : 'badge-gray'
                      }`}>{n.sentiment}</span>
                      <span className="text-[10px] text-gray-500">{n.source}</span>
                    </div>
                    <div className="text-sm font-medium leading-snug">{n.title}</div>
                  </a>
                ))}
              </div>
            </div>

            {/* Full Report Summary */}
            <div className="glass rounded-2xl p-5">
              <h3 className="text-sm font-semibold mb-3">Analyst Summary</h3>
              <div className="text-sm text-gray-300 leading-relaxed space-y-2">
                <p>
                  <span className="text-cyber-blue font-medium">{token.symbol}</span> on {chainLabel(token.chain)} scores{' '}
                  <span className="font-orbitron text-cyber-gold">{scores.final}</span>/100 →{' '}
                  <span className="font-semibold">{scores.verdict}</span>.
                </p>
                <p className="text-gray-400">
                  Liquidity {formatUsd(token.liquidityUsd)} · 24h volume {formatUsd(token.volume24h)} ·
                  Price {formatPrice(token.priceUsd)} ({token.priceChange24h >= 0 ? '+' : ''}{token.priceChange24h.toFixed(2)}% 24h).
                </p>
                {security && (
                  <p className="text-gray-400">
                    Security ({security.source}): {scores.security}/100
                    {security.risks?.length
                      ? ` — flags: ${security.risks.map((r) => r.label).join(', ')}`
                      : ' — no major flags'}.
                  </p>
                )}
                {whale && (
                  <p className="text-gray-400">
                    Flow signal: <span className="text-white">{whale.type}</span> (strength {whale.strength}). {whale.note}
                  </p>
                )}
                <p className="text-xs text-gray-500 pt-2">
                  Weights: Liquidity 22% · Security 22% · Activity 18% · Momentum 14% · Buy pressure 12% · Pair age 12%.
                  This is a research heuristic, not financial advice.
                </p>
              </div>
            </div>

            {/* Top pools detail */}
            {token.allPairs?.length > 0 && (
              <div className="glass rounded-2xl p-5">
                <h3 className="text-sm font-semibold mb-3">Liquidity Pools</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-xs text-gray-500 text-left">
                        <th className="pb-2 font-medium">DEX</th>
                        <th className="pb-2 font-medium">Liquidity</th>
                        <th className="pb-2 font-medium">24h Volume</th>
                      </tr>
                    </thead>
                    <tbody>
                      {token.allPairs.map((p, i) => (
                        <tr key={i} className="border-t border-white/5">
                          <td className="py-2 text-gray-300">{p.dex}</td>
                          <td className="py-2">{formatUsd(p.liquidity)}</td>
                          <td className="py-2 text-gray-400">{formatUsd(p.volume24h)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <a
                  href={token.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-block mt-3 text-xs text-cyber-blue hover:underline"
                >
                  Open on DexScreener ↗
                </a>
              </div>
            )}

            <p className="text-[11px] text-gray-600 text-center">
              Data: DexScreener · GoPlus · RugCheck · News APIs. Scores are heuristic. Not financial advice.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

export default function DashboardPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-cyber-blue">Loading terminal...</div>}>
      <DashboardInner />
    </Suspense>
  );
}
