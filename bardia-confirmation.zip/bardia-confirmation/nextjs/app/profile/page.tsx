'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import { useSession } from '@/lib/session';

type Profile = {
  id: number;
  email: string;
  username: string | null;
  avatarUrl: string | null;
  plan: string;
  riskProfile: string;
  createdAt: string;
};

export default function ProfilePage() {
  const { user, loading: sessionLoading, refresh } = useSession();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [stats, setStats] = useState({ analyses: 0, watchlist: 0 });
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  // form
  const [username, setUsername] = useState('');
  const [riskProfile, setRiskProfile] = useState('moderate');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (sessionLoading) return;
    if (!user) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const res = await fetch('/api/profile');
        if (!res.ok) {
          setErr('Could not load profile');
          return;
        }
        const data = await res.json();
        setProfile(data.user);
        setStats(data.stats || { analyses: 0, watchlist: 0 });
        setUsername(data.user.username || '');
        setRiskProfile(data.user.riskProfile || 'moderate');
      } catch {
        setErr('Network error');
      } finally {
        setLoading(false);
      }
    })();
  }, [user, sessionLoading]);

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    setMsg('');
    setErr('');
    setSaving(true);
    try {
      const body: any = {
        username,
        riskProfile,
      };
      if (newPassword) {
        body.currentPassword = currentPassword;
        body.newPassword = newPassword;
      }
      const res = await fetch('/api/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        setErr(data.error || 'Update failed');
        return;
      }
      setMsg('Settings saved');
      setCurrentPassword('');
      setNewPassword('');
      refresh();
    } catch {
      setErr('Network error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 py-10">
        <h1 className="font-orbitron text-2xl font-bold mb-1">Profile & Settings</h1>
        <p className="text-sm text-gray-500 mb-8">Manage your account and risk preferences.</p>

        {!sessionLoading && !user && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="text-gray-400 mb-4">Sign in to manage your profile.</p>
            <div className="flex justify-center gap-3">
              <Link href="/login" className="btn-primary px-5 py-2 rounded-lg text-sm">Login</Link>
              <Link href="/register" className="border border-white/10 px-5 py-2 rounded-lg text-sm text-gray-300">
                Sign up
              </Link>
            </div>
          </div>
        )}

        {loading && user && <p className="text-sm text-gray-500">Loading...</p>}

        {!loading && profile && (
          <div className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="glass rounded-xl p-4 text-center">
                <div className="text-2xl font-orbitron font-bold text-cyber-blue">{stats.analyses}</div>
                <div className="text-[11px] text-gray-500 mt-1">Analyses</div>
              </div>
              <div className="glass rounded-xl p-4 text-center">
                <div className="text-2xl font-orbitron font-bold text-cyber-gold">{stats.watchlist}</div>
                <div className="text-[11px] text-gray-500 mt-1">Watchlist</div>
              </div>
              <div className="glass rounded-xl p-4 text-center">
                <div className="text-sm font-orbitron font-bold text-cyber-green uppercase mt-1">{profile.plan}</div>
                <div className="text-[11px] text-gray-500 mt-1">Plan</div>
              </div>
            </div>

            {/* Account info */}
            <div className="glass rounded-2xl p-6">
              <h2 className="text-sm font-semibold mb-4">Account</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Email</span>
                  <span>{profile.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Member since</span>
                  <span>{profile.createdAt ? new Date(profile.createdAt).toLocaleDateString() : '—'}</span>
                </div>
              </div>
            </div>

            {/* Settings form */}
            <form onSubmit={saveProfile} className="glass rounded-2xl p-6 space-y-4">
              <h2 className="text-sm font-semibold mb-2">Settings</h2>

              <div>
                <label className="text-xs text-gray-500 mb-1 block">Username</label>
                <input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="cyber-input w-full px-4 py-2.5 rounded-xl text-sm"
                  placeholder="trader_pro"
                />
              </div>

              <div>
                <label className="text-xs text-gray-500 mb-1 block">Risk profile</label>
                <select
                  value={riskProfile}
                  onChange={(e) => setRiskProfile(e.target.value)}
                  className="cyber-input w-full px-4 py-2.5 rounded-xl text-sm"
                >
                  <option value="conservative">Conservative</option>
                  <option value="moderate">Moderate</option>
                  <option value="aggressive">Aggressive</option>
                </select>
                <p className="text-[11px] text-gray-600 mt-1">
                  Influences how aggressive trading signals and alerts will be interpreted.
                </p>
                <ul className="mt-2 text-[11px] text-gray-500 space-y-1 list-disc list-inside">
                  <li><span className="text-gray-400">Conservative</span> — prioritizes security & liquidity; fewer high-risk flags</li>
                  <li><span className="text-gray-400">Moderate</span> — balanced default for most traders</li>
                  <li><span className="text-gray-400">Aggressive</span> — tolerates newer pairs and higher volatility</li>
                </ul>
              </div>

              <div className="rounded-xl bg-white/5 p-4 text-xs text-gray-400 space-y-1">
                <div className="text-gray-300 font-medium mb-1">What gets saved</div>
                <p>• Every analysis while logged in is stored in History with full report JSON.</p>
                <p>• Watchlist is private to your account.</p>
                <p>• Global token score cache is shared (not personal).</p>
              </div>

              <div className="border-t border-white/5 pt-4">
                <h3 className="text-xs text-gray-500 mb-3">Change password</h3>
                <div className="space-y-3">
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="cyber-input w-full px-4 py-2.5 rounded-xl text-sm"
                    placeholder="Current password"
                  />
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="cyber-input w-full px-4 py-2.5 rounded-xl text-sm"
                    placeholder="New password (min 8 chars)"
                    minLength={8}
                  />
                </div>
              </div>

              {err && <div className="text-sm text-cyber-red bg-red-500/10 rounded-lg px-3 py-2">{err}</div>}
              {msg && <div className="text-sm text-cyber-green bg-green-500/10 rounded-lg px-3 py-2">{msg}</div>}

              <button
                type="submit"
                disabled={saving}
                className="btn-primary w-full py-3 rounded-xl text-sm disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save settings'}
              </button>
            </form>

            <div className="flex gap-4 text-sm">
              <Link href="/history" className="text-cyber-blue hover:underline">Analysis history →</Link>
              <Link href="/watchlist" className="text-cyber-blue hover:underline">Watchlist →</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
