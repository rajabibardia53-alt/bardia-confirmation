import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'BARDIA CONFIRMATION — Research Terminal',
  description: 'Institutional-Grade Memecoin & Smart Money Research Terminal',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
