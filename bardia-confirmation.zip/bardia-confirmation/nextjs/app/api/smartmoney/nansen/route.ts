import { NextRequest, NextResponse } from 'next/server';
import { fetchNansenServer } from '@/lib/enterprise';

export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get('address');
  const chain = req.nextUrl.searchParams.get('chain') || 'ethereum';

  if (!address) {
    return NextResponse.json({ error: 'address required' }, { status: 400 });
  }

  if (!process.env.NANSEN_API_KEY) {
    return NextResponse.json(
      {
        provider: 'nansen',
        available: false,
        note: 'NANSEN_API_KEY not configured. Enterprise contract required.',
      },
      { status: 503 }
    );
  }

  const data = await fetchNansenServer(address, chain);
  return NextResponse.json(data);
}
