import { NextRequest, NextResponse } from 'next/server';
import { fetchArkhamServer } from '@/lib/enterprise';

export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get('address');
  const chain = req.nextUrl.searchParams.get('chain') || 'ethereum';

  if (!address) {
    return NextResponse.json({ error: 'address required' }, { status: 400 });
  }

  if (!process.env.ARKHAM_API_KEY) {
    return NextResponse.json(
      {
        provider: 'arkham',
        available: false,
        note: 'ARKHAM_API_KEY not configured. Enterprise contract required.',
      },
      { status: 503 }
    );
  }

  const data = await fetchArkhamServer(address, chain);
  return NextResponse.json(data);
}
