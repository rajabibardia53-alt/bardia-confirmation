import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { saveAnalysis, upsertTokenScore } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    const body = await req.json();

    const tokenAddress = String(body.tokenAddress || '');
    const chain = String(body.chain || 'unknown');
    const finalScore = Number(body.finalScore);
    const verdict = String(body.verdict || '');
    const fullReport = body.fullReport || {};

    if (!tokenAddress || Number.isNaN(finalScore)) {
      return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
    }

    // Always upsert global token score cache
    await upsertTokenScore({
      tokenAddress,
      chain,
      score: finalScore,
      verdict,
      data: fullReport,
    });

    // Save to user history only if logged in
    let historyId = null;
    if (session) {
      const rows = await saveAnalysis({
        userId: session.id,
        tokenAddress,
        chain,
        finalScore,
        verdict,
        fullReport,
        preferredLlm: body.preferredLlm,
      });
      historyId = rows[0]?.id ?? null;
    }

    return NextResponse.json({
      ok: true,
      savedToHistory: Boolean(session),
      historyId,
    });
  } catch (e: any) {
    console.error('[analyze/save]', e);
    return NextResponse.json({ error: e.message || 'Save failed' }, { status: 500 });
  }
}
