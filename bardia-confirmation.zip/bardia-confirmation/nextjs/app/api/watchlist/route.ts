import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { getWatchlist, addToWatchlist, query } from '@/lib/db';

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const items = await getWatchlist(session.id);
  return NextResponse.json({ items });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json();
  const tokenAddress = String(body.tokenAddress || '').trim();
  const chain = String(body.chain || 'unknown');
  const symbol = body.symbol ? String(body.symbol) : undefined;
  const name = body.name ? String(body.name) : undefined;

  if (!tokenAddress) {
    return NextResponse.json({ error: 'tokenAddress required' }, { status: 400 });
  }

  const result = await addToWatchlist({
    userId: session.id,
    tokenAddress,
    chain,
    symbol,
    name,
  });

  if (!result.length) {
    // might be conflict or DB down
    return NextResponse.json({ ok: true, message: 'Already in watchlist or DB unavailable' });
  }

  return NextResponse.json({ ok: true, id: result[0]?.id });
}

export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const id = req.nextUrl.searchParams.get('id');
  if (!id) {
    return NextResponse.json({ error: 'id required' }, { status: 400 });
  }

  await query('DELETE FROM watchlists WHERE id = $1 AND user_id = $2', [id, session.id]);
  return NextResponse.json({ ok: true });
}
