import { NextRequest, NextResponse } from 'next/server';
import { getSession, hashPassword, verifyPassword } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const user = await queryOne<{
    id: number;
    email: string;
    username: string | null;
    avatar_url: string | null;
    subscription_plan: string;
    risk_profile: string;
    created_at: string;
  }>(
    `SELECT id, email, username, avatar_url, subscription_plan, risk_profile, created_at
     FROM users WHERE id = $1`,
    [session.id]
  );

  if (!user) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 });
  }

  // Stats
  const analysisCount = await queryOne<{ count: string }>(
    'SELECT COUNT(*)::text AS count FROM analysis_history WHERE user_id = $1',
    [session.id]
  );
  const watchCount = await queryOne<{ count: string }>(
    'SELECT COUNT(*)::text AS count FROM watchlists WHERE user_id = $1',
    [session.id]
  );

  return NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      avatarUrl: user.avatar_url,
      plan: user.subscription_plan || 'free',
      riskProfile: user.risk_profile || 'moderate',
      createdAt: user.created_at,
    },
    stats: {
      analyses: Number(analysisCount?.count || 0),
      watchlist: Number(watchCount?.count || 0),
    },
  });
}

export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json();
  const updates: string[] = [];
  const params: any[] = [];
  let i = 1;

  if (body.username !== undefined) {
    updates.push(`username = $${i++}`);
    params.push(String(body.username).trim() || null);
  }
  if (body.riskProfile !== undefined) {
    const allowed = ['conservative', 'moderate', 'aggressive'];
    const rp = String(body.riskProfile);
    if (!allowed.includes(rp)) {
      return NextResponse.json({ error: 'Invalid risk profile' }, { status: 400 });
    }
    updates.push(`risk_profile = $${i++}`);
    params.push(rp);
  }
  if (body.avatarUrl !== undefined) {
    updates.push(`avatar_url = $${i++}`);
    params.push(body.avatarUrl ? String(body.avatarUrl) : null);
  }

  // Password change
  if (body.newPassword) {
    if (!body.currentPassword) {
      return NextResponse.json({ error: 'Current password required' }, { status: 400 });
    }
    if (String(body.newPassword).length < 8) {
      return NextResponse.json({ error: 'New password min 8 chars' }, { status: 400 });
    }
    const row = await queryOne<{ password_hash: string }>(
      'SELECT password_hash FROM users WHERE id = $1',
      [session.id]
    );
    if (!row) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }
    const ok = await verifyPassword(String(body.currentPassword), row.password_hash);
    if (!ok) {
      return NextResponse.json({ error: 'Current password is wrong' }, { status: 403 });
    }
    const hash = await hashPassword(String(body.newPassword));
    updates.push(`password_hash = $${i++}`);
    params.push(hash);
  }

  if (updates.length === 0) {
    return NextResponse.json({ error: 'Nothing to update' }, { status: 400 });
  }

  updates.push('updated_at = NOW()');
  params.push(session.id);

  await query(
    `UPDATE users SET ${updates.join(', ')} WHERE id = $${i}`,
    params
  );

  return NextResponse.json({ ok: true });
}
