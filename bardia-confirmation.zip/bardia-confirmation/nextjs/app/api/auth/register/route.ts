import { NextRequest, NextResponse } from 'next/server';
import { createUser, getUserByEmail } from '@/lib/db';
import { hashPassword, signSession, sessionCookieOptions } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const username = body.username ? String(body.username).trim() : undefined;

    if (!email || !password || password.length < 8) {
      return NextResponse.json(
        { error: 'Email and password (min 8 chars) required' },
        { status: 400 }
      );
    }

    const existing = await getUserByEmail(email);
    if (existing) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
    }

    const passwordHash = await hashPassword(password);
    const user = await createUser({ email, passwordHash, username });
    if (!user) {
      return NextResponse.json(
        { error: 'Database not configured. Set DATABASE_URL.' },
        { status: 503 }
      );
    }

    const token = await signSession({
      id: user.id,
      email: user.email,
      username: username ?? null,
      plan: 'free',
    });

    const res = NextResponse.json({
      user: { id: user.id, email: user.email, username, plan: 'free' },
    });
    res.cookies.set(sessionCookieOptions(token));
    return res;
  } catch (e: any) {
    console.error('[register]', e);
    return NextResponse.json({ error: e.message || 'Register failed' }, { status: 500 });
  }
}
