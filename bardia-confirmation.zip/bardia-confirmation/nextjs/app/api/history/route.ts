import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';

export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') || 50), 100);
  const offset = Math.max(Number(req.nextUrl.searchParams.get('offset') || 0), 0);

  const items = await query(
    `SELECT id, token_address, chain, final_score, verdict, preferred_llm, created_at,
            full_report
     FROM analysis_history
     WHERE user_id = $1
     ORDER BY created_at DESC
     LIMIT $2 OFFSET $3`,
    [session.id, limit, offset]
  );

  const countRow = await queryOne<{ count: string }>(
    'SELECT COUNT(*)::text AS count FROM analysis_history WHERE user_id = $1',
    [session.id]
  );

  return NextResponse.json({
    items,
    total: Number(countRow?.count || 0),
    limit,
    offset,
  });
}

export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const id = req.nextUrl.searchParams.get('id');
  if (!id) {
    return NextResponse.json({ error: 'id required' }, { status: 400 });
  }

  await query('DELETE FROM analysis_history WHERE id = $1 AND user_id = $2', [
    id,
    session.id,
  ]);

  return NextResponse.json({ ok: true });
}
