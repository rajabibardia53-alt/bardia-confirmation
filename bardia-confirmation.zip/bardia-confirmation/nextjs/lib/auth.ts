/**
 * Auth helpers — JWT session cookies (no NextAuth dependency required)
 *
 * For production you can swap to NextAuth / Clerk / Supabase Auth.
 * This implementation uses:
 *   - bcryptjs for password hashing
 *   - jose for JWT
 *   - httpOnly cookie: bardia_session
 *
 * Install: npm i bcryptjs jose  && npm i -D @types/bcryptjs
 */

import { cookies } from 'next/headers';

const COOKIE_NAME = 'bardia_session';
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-me-in-production-32chars';
const JWT_ISSUER = 'bardia-confirmation';
const MAX_AGE_SEC = 60 * 60 * 24 * 7; // 7 days

export type SessionUser = {
  id: number;
  email: string;
  username?: string | null;
  plan: string;
};

async function getJose() {
  return import('jose');
}

async function getBcrypt() {
  return import('bcryptjs');
}

export async function hashPassword(plain: string): Promise<string> {
  const bcrypt = await getBcrypt();
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  const bcrypt = await getBcrypt();
  return bcrypt.compare(plain, hash);
}

export async function signSession(user: SessionUser): Promise<string> {
  const { SignJWT } = await getJose();
  const secret = new TextEncoder().encode(JWT_SECRET);
  return new SignJWT({
    sub: String(user.id),
    email: user.email,
    username: user.username,
    plan: user.plan,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setIssuer(JWT_ISSUER)
    .setExpirationTime(`${MAX_AGE_SEC}s`)
    .sign(secret);
}

export async function verifySessionToken(token: string): Promise<SessionUser | null> {
  try {
    const { jwtVerify } = await getJose();
    const secret = new TextEncoder().encode(JWT_SECRET);
    const { payload } = await jwtVerify(token, secret, { issuer: JWT_ISSUER });
    return {
      id: Number(payload.sub),
      email: String(payload.email),
      username: (payload.username as string) || null,
      plan: String(payload.plan || 'free'),
    };
  } catch {
    return null;
  }
}

export async function getSession(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

export function sessionCookieOptions(token: string) {
  return {
    name: COOKIE_NAME,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax' as const,
    path: '/',
    maxAge: MAX_AGE_SEC,
  };
}

export function clearSessionCookie() {
  return {
    name: COOKIE_NAME,
    value: '',
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax' as const,
    path: '/',
    maxAge: 0,
  };
}
