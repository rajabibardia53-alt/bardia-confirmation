/**
 * Bardia Confirmation — API Layer (TypeScript)
 * DexScreener + GoPlus + RugCheck + News
 */

export type TokenData = {
  address: string;
  symbol: string;
  name: string;
  chain: string;
  dex: string;
  pairAddress: string;
  priceUsd: number;
  priceChange24h: number;
  liquidityUsd: number;
  volume24h: number;
  fdv: number;
  marketCap: number;
  txns24h: number;
  buys24h: number;
  sells24h: number;
  pairCreatedAt: number | null;
  url: string;
  imageUrl: string | null;
  allPairs: { dex: string; liquidity: number; volume24h: number }[];
};

export type SecurityData = {
  source: string;
  securityScore: number;
  isHoneypot?: boolean;
  canMint?: boolean;
  canFreeze?: boolean;
  lpLockedPct?: number | null;
  risks: { level: string; label: string; value?: string; description?: string }[];
};

export type NewsItem = {
  title: string;
  source: string;
  url: string;
  publishedAt: string | null;
  body: string;
  sentiment: 'positive' | 'negative' | 'neutral';
};

export type Scores = {
  final: number;
  verdict: string;
  liquidity: number;
  activity: number;
  momentum: number;
  buyPressure: number;
  age: number;
  security: number;
};

const CHAIN_ID_MAP: Record<string, string> = {
  ethereum: '1', bsc: '56', polygon: '137', arbitrum: '42161',
  optimism: '10', avalanche: '43114', base: '8453',
};

export async function getTokenByAddress(address: string) {
  const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${address}`);
  if (!res.ok) throw new Error(`DexScreener error: ${res.status}`);
  return res.json();
}

export function normalizeToken(dexData: any): TokenData | null {
  if (!dexData?.pairs?.length) return null;
  const pairs = [...dexData.pairs].sort(
    (a: any, b: any) => parseFloat(b.liquidity?.usd || 0) - parseFloat(a.liquidity?.usd || 0)
  );
  const best = pairs[0];
  return {
    address: best.baseToken?.address || '',
    symbol: best.baseToken?.symbol || '???',
    name: best.baseToken?.name || 'Unknown',
    chain: best.chainId || 'unknown',
    dex: best.dexId || '',
    pairAddress: best.pairAddress || '',
    priceUsd: parseFloat(best.priceUsd || 0),
    priceChange24h: best.priceChange?.h24 ?? 0,
    liquidityUsd: parseFloat(best.liquidity?.usd || 0),
    volume24h: parseFloat(best.volume?.h24 || 0),
    fdv: parseFloat(best.fdv || best.marketCap || 0),
    marketCap: parseFloat(best.marketCap || best.fdv || 0),
    txns24h: (best.txns?.h24?.buys || 0) + (best.txns?.h24?.sells || 0),
    buys24h: best.txns?.h24?.buys || 0,
    sells24h: best.txns?.h24?.sells || 0,
    pairCreatedAt: best.pairCreatedAt || null,
    url: best.url || `https://dexscreener.com/${best.chainId}/${best.pairAddress}`,
    imageUrl: best.info?.imageUrl || null,
    allPairs: pairs.slice(0, 5).map((p: any) => ({
      dex: p.dexId,
      liquidity: parseFloat(p.liquidity?.usd || 0),
      volume24h: parseFloat(p.volume?.h24 || 0),
    })),
  };
}

export async function getGoPlusSecurity(address: string, chainId: string) {
  try {
    if (chainId === 'solana') {
      const res = await fetch(
        `https://api.gopluslabs.io/api/v1/solana/token_security?contract_addresses=${address}`
      );
      if (!res.ok) return null;
      const data = await res.json();
      return data?.result?.[address] || data?.result || null;
    }
    const cid = CHAIN_ID_MAP[chainId?.toLowerCase()] || '1';
    const res = await fetch(
      `https://api.gopluslabs.io/api/v1/token_security/${cid}?contract_addresses=${address}`
    );
    if (!res.ok) return null;
    const data = await res.json();
    const key = Object.keys(data?.result || {}).find(
      (k) => k.toLowerCase() === address.toLowerCase()
    );
    return key ? data.result[key] : null;
  } catch {
    return null;
  }
}

export function normalizeGoPlus(raw: any): SecurityData | null {
  if (!raw) return null;
  const isHoneypot = raw.is_honeypot === '1' || raw.is_honeypot === true;
  const canMint = raw.can_take_back_ownership === '1' || raw.mintable === '1' || raw.is_mintable === '1';
  const canFreeze = raw.transfer_pausable === '1' || raw.freezable === '1';
  const hasBlacklist = raw.is_blacklisted === '1';
  const buyTax = parseFloat(raw.buy_tax || 0) * 100;
  const sellTax = parseFloat(raw.sell_tax || 0) * 100;
  const isOpenSource = raw.is_open_source === '1';

  let risk = 0;
  if (isHoneypot) risk += 40;
  if (canMint) risk += 15;
  if (canFreeze) risk += 12;
  if (hasBlacklist) risk += 10;
  if (buyTax > 10 || sellTax > 10) risk += 10;
  else if (buyTax > 5 || sellTax > 5) risk += 5;
  if (!isOpenSource) risk += 5;

  return {
    source: 'GoPlus',
    securityScore: Math.max(0, 100 - risk),
    isHoneypot,
    canMint,
    canFreeze,
    risks: [
      isHoneypot && { level: 'danger', label: 'Honeypot Detected' },
      canMint && { level: 'warn', label: 'Mintable' },
      canFreeze && { level: 'warn', label: 'Freezable / Pausable' },
      hasBlacklist && { level: 'warn', label: 'Has Blacklist' },
      (buyTax > 10 || sellTax > 10) && { level: 'danger', label: `High Tax` },
      !isOpenSource && { level: 'info', label: 'Not Open Source' },
    ].filter(Boolean) as SecurityData['risks'],
  };
}

export async function getRugCheck(address: string) {
  try {
    const res = await fetch(`https://api.rugcheck.xyz/v1/tokens/${address}/report/summary`);
    if (res.ok) return res.json();
    const full = await fetch(`https://api.rugcheck.xyz/v1/tokens/${address}/report`);
    if (full.ok) return full.json();
    return null;
  } catch {
    return null;
  }
}

export function normalizeRugCheck(raw: any): SecurityData | null {
  if (!raw) return null;
  const scoreNormalised = raw.score_normalised ?? raw.score ?? null;
  let securityScore = 50;
  if (typeof scoreNormalised === 'number') {
    securityScore = Math.max(0, Math.min(100, 100 - scoreNormalised));
  }
  return {
    source: 'RugCheck',
    securityScore: Math.round(securityScore),
    lpLockedPct: raw.lpLockedPct ?? null,
    risks: (raw.risks || []).map((r: any) => ({
      level: r.level === 'danger' ? 'danger' : r.level === 'warn' ? 'warn' : 'info',
      label: r.name || 'Risk',
      value: r.value || '',
      description: r.description || '',
    })),
  };
}

export async function getLatestNews(limit = 8): Promise<NewsItem[]> {
  try {
    const res = await fetch(
      'https://min-api.cryptocompare.com/data/v2/news/?lang=EN&categories=BTC,ETH,SOL,Blockchain,Trading'
    );
    if (res.ok) {
      const data = await res.json();
      return (data.Data || []).slice(0, limit).map((item: any) => ({
        title: item.title,
        source: item.source_info?.name || item.source || 'CryptoCompare',
        url: item.url || item.guid,
        publishedAt: item.published_on
          ? new Date(item.published_on * 1000).toISOString()
          : null,
        body: (item.body || '').slice(0, 180),
        sentiment: simpleSentiment(item.title + ' ' + (item.body || '')),
      }));
    }
  } catch {}
  return [];
}

function simpleSentiment(text: string): 'positive' | 'negative' | 'neutral' {
  const t = text.toLowerCase();
  const bull = ['partnership', 'launch', 'approval', 'surge', 'rally', 'bullish', 'adoption', 'etf'];
  const bear = ['hack', 'exploit', 'ban', 'lawsuit', 'crash', 'bearish', 'rug', 'scam'];
  let s = 0;
  bull.forEach((w) => { if (t.includes(w)) s++; });
  bear.forEach((w) => { if (t.includes(w)) s--; });
  if (s > 0) return 'positive';
  if (s < 0) return 'negative';
  return 'neutral';
}

export function calculateScores(token: TokenData, security: SecurityData | null): Scores {
  let liquidityScore = 20;
  if (token.liquidityUsd > 5e6) liquidityScore = 95;
  else if (token.liquidityUsd > 1e6) liquidityScore = 85;
  else if (token.liquidityUsd > 250000) liquidityScore = 70;
  else if (token.liquidityUsd > 50000) liquidityScore = 50;
  else if (token.liquidityUsd > 10000) liquidityScore = 30;

  let activityScore = 20;
  if (token.volume24h > 1e7) activityScore = 95;
  else if (token.volume24h > 2e6) activityScore = 80;
  else if (token.volume24h > 5e5) activityScore = 65;
  else if (token.volume24h > 1e5) activityScore = 45;
  else if (token.volume24h > 2e4) activityScore = 30;

  let momentumScore = 50;
  const ch = token.priceChange24h;
  if (ch > 50) momentumScore = 90;
  else if (ch > 20) momentumScore = 80;
  else if (ch > 5) momentumScore = 65;
  else if (ch > 0) momentumScore = 55;
  else if (ch > -10) momentumScore = 40;
  else if (ch > -30) momentumScore = 25;
  else momentumScore = 10;

  const totalTx = token.buys24h + token.sells24h;
  const buyPressure = totalTx > 0 ? Math.round((token.buys24h / totalTx) * 100) : 50;

  let ageScore = 60;
  if (token.pairCreatedAt) {
    const h = (Date.now() - token.pairCreatedAt) / 36e5;
    if (h < 24) ageScore = 25;
    else if (h < 72) ageScore = 40;
    else if (h < 168) ageScore = 55;
    else if (h < 720) ageScore = 70;
    else ageScore = 85;
  }

  const securityScore = security?.securityScore ?? 50;
  const final =
    liquidityScore * 0.22 +
    activityScore * 0.18 +
    momentumScore * 0.14 +
    buyPressure * 0.12 +
    ageScore * 0.12 +
    securityScore * 0.22;

  const clamped = Math.max(0, Math.min(100, final));
  let verdict = 'RISKY';
  if (clamped >= 80) verdict = 'STRONG BUY';
  else if (clamped >= 65) verdict = 'BUY';
  else if (clamped >= 45) verdict = 'NEUTRAL';
  else if (clamped >= 30) verdict = 'CAUTION';

  return {
    final: Math.round(clamped * 10) / 10,
    verdict,
    liquidity: Math.round(liquidityScore),
    activity: Math.round(activityScore),
    momentum: Math.round(momentumScore),
    buyPressure: Math.round(buyPressure),
    age: Math.round(ageScore),
    security: Math.round(securityScore),
  };
}

export function formatPrice(p: number) {
  if (!p) return '$0.00';
  if (p < 1e-6) return `$${p.toExponential(2)}`;
  if (p < 0.01) return `$${p.toFixed(8)}`;
  if (p < 1) return `$${p.toFixed(6)}`;
  if (p < 1000) return `$${p.toFixed(4)}`;
  return `$${p.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

export function formatUsd(n: number) {
  if (!n) return '$0';
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(0)}`;
}

export function chainLabel(id: string) {
  const m: Record<string, string> = {
    solana: 'Solana', ethereum: 'Ethereum', base: 'Base', bsc: 'BNB Chain',
    arbitrum: 'Arbitrum', polygon: 'Polygon', avalanche: 'Avalanche', optimism: 'Optimism',
  };
  return m[id?.toLowerCase()] || id || 'Unknown';
}


// ==================== CryptoPanic News ====================
// Set NEXT_PUBLIC_CRYPTOPANIC_TOKEN in .env.local
const CRYPTOPANIC_TOKEN = process.env.NEXT_PUBLIC_CRYPTOPANIC_TOKEN || '';

export async function getCryptoPanicNews(
  filter: string = 'hot',
  currencies?: string,
  limit = 10
): Promise<NewsItem[]> {
  if (!CRYPTOPANIC_TOKEN) {
    // Fallback to CryptoCompare when no key
    return getLatestNews(limit);
  }
  try {
    const params = new URLSearchParams({
      auth_token: CRYPTOPANIC_TOKEN,
      public: 'true',
      filter,
    });
    if (currencies) params.set('currencies', currencies);
    const res = await fetch(`https://cryptopanic.com/api/v1/posts/?${params}`);
    if (!res.ok) return getLatestNews(limit);
    const data = await res.json();
    return (data.results || []).slice(0, limit).map((item: any) => ({
      title: item.title,
      source: item.source?.title || 'CryptoPanic',
      url: item.url,
      publishedAt: item.published_at || item.created,
      body: item.title,
      sentiment:
        item.votes?.positive > item.votes?.negative
          ? 'positive'
          : item.votes?.negative > item.votes?.positive
          ? 'negative'
          : 'neutral',
    }));
  } catch {
    return getLatestNews(limit);
  }
}

// ==================== Whale / Smart Money (heuristic from DexScreener) ====================
export type WhaleSignal = {
  type: 'accumulation' | 'distribution' | 'neutral';
  strength: number; // 0-100
  note: string;
  buyRatio: number;
  volumeToLiquidity: number;
};

export function analyzeWhaleActivity(token: TokenData): WhaleSignal {
  const totalTx = token.buys24h + token.sells24h || 1;
  const buyRatio = token.buys24h / totalTx;
  const volToLiq = token.liquidityUsd > 0 ? token.volume24h / token.liquidityUsd : 0;

  let type: WhaleSignal['type'] = 'neutral';
  let strength = 50;
  let note = 'Balanced flow — no clear whale bias';

  // High volume relative to liquidity + strong buy pressure → possible accumulation
  if (buyRatio > 0.62 && volToLiq > 0.8) {
    type = 'accumulation';
    strength = Math.min(95, 60 + buyRatio * 30 + Math.min(volToLiq, 3) * 8);
    note = 'Strong buy pressure with elevated volume — possible smart money accumulation';
  } else if (buyRatio < 0.38 && volToLiq > 0.8) {
    type = 'distribution';
    strength = Math.min(95, 60 + (1 - buyRatio) * 30 + Math.min(volToLiq, 3) * 8);
    note = 'Heavy sell pressure with high volume — possible distribution';
  } else if (buyRatio > 0.55) {
    type = 'accumulation';
    strength = 55 + buyRatio * 20;
    note = 'Mild buy-side dominance';
  } else if (buyRatio < 0.45) {
    type = 'distribution';
    strength = 55 + (1 - buyRatio) * 20;
    note = 'Mild sell-side dominance';
  }

  return {
    type,
    strength: Math.round(strength),
    note,
    buyRatio: Math.round(buyRatio * 100),
    volumeToLiquidity: Math.round(volToLiq * 100) / 100,
  };
}
