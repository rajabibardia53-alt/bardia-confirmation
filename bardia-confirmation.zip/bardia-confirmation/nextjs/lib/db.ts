/**
 * Database layer — PostgreSQL via `pg` (or Prisma later)
 *
 * Schema matches the original Bardia Confirmation spec:
 * users, wallets, watchlists, analysis_history, trades, alerts, news_cache, token_scores
 *
 * Setup:
 *   1. Create a Postgres DB (local, Supabase, Neon, Railway, ...)
 *   2. Set DATABASE_URL in .env.local
 *   3. Run the SQL in prisma/schema.sql (or this file's SCHEMA_SQL)
 *   4. npm i pg  (+ @types/pg for TS)
 */

export const SCHEMA_SQL = `
-- Users
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  avatar_url TEXT,
  subscription_plan VARCHAR(50) DEFAULT 'free',
  risk_profile VARCHAR(20) DEFAULT 'moderate',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Wallets
CREATE TABLE IF NOT EXISTS wallets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  address TEXT NOT NULL,
  chain VARCHAR(30) NOT NULL,
  label VARCHAR(100),
  is_primary BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Watchlists
CREATE TABLE IF NOT EXISTS watchlists (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token_address TEXT NOT NULL,
  chain VARCHAR(30),
  symbol VARCHAR(30),
  name VARCHAR(100),
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, token_address, chain)
);

-- Analysis History
CREATE TABLE IF NOT EXISTS analysis_history (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  token_address TEXT NOT NULL,
  chain VARCHAR(30),
  final_score DECIMAL(5,2),
  verdict VARCHAR(30),
  full_report JSONB,
  preferred_llm VARCHAR(20),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analysis_token ON analysis_history(token_address);
CREATE INDEX IF NOT EXISTS idx_analysis_user ON analysis_history(user_id);

-- Trades
CREATE TABLE IF NOT EXISTS trades (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token_address TEXT,
  chain VARCHAR(30),
  side VARCHAR(10),
  amount NUMERIC,
  price NUMERIC,
  tx_hash TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Alerts
CREATE TABLE IF NOT EXISTS alerts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token_address TEXT,
  alert_type VARCHAR(50),
  condition JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- News Cache
CREATE TABLE IF NOT EXISTS news_cache (
  id SERIAL PRIMARY KEY,
  title TEXT,
  summary TEXT,
  source VARCHAR(100),
  url TEXT,
  related_tokens TEXT[],
  sentiment VARCHAR(20),
  published_at TIMESTAMPTZ,
  fetched_at TIMESTAMPTZ DEFAULT NOW()
);

-- Token Scores (fast lookup)
CREATE TABLE IF NOT EXISTS token_scores (
  id SERIAL PRIMARY KEY,
  token_address TEXT UNIQUE,
  chain VARCHAR(30),
  bardia_score DECIMAL(5,2),
  verdict VARCHAR(30),
  last_analyzed TIMESTAMPTZ,
  data JSONB
);

CREATE INDEX IF NOT EXISTS idx_token_scores_addr ON token_scores(token_address);
`;

// Lightweight query helper — only active when DATABASE_URL is set
let pool: any = null;

export async function getPool() {
  if (pool) return pool;
  const url = process.env.DATABASE_URL;
  if (!url) return null;

  try {
    // Dynamic import so the app still builds without `pg` installed
    const { Pool } = await import('pg');
    pool = new Pool({ connectionString: url, max: 10 });
    return pool;
  } catch {
    console.warn('[db] pg package not installed or DATABASE_URL invalid');
    return null;
  }
}

export async function query<T = any>(text: string, params?: any[]): Promise<T[]> {
  const p = await getPool();
  if (!p) return [];
  const res = await p.query(text, params);
  return res.rows as T[];
}

export async function queryOne<T = any>(text: string, params?: any[]): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows[0] ?? null;
}

// ---------- Domain helpers ----------

export async function saveAnalysis(opts: {
  userId?: number | null;
  tokenAddress: string;
  chain: string;
  finalScore: number;
  verdict: string;
  fullReport: object;
  preferredLlm?: string;
}) {
  return query(
    `INSERT INTO analysis_history
      (user_id, token_address, chain, final_score, verdict, full_report, preferred_llm)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     RETURNING id`,
    [
      opts.userId ?? null,
      opts.tokenAddress,
      opts.chain,
      opts.finalScore,
      opts.verdict,
      JSON.stringify(opts.fullReport),
      opts.preferredLlm ?? null,
    ]
  );
}

export async function upsertTokenScore(opts: {
  tokenAddress: string;
  chain: string;
  score: number;
  verdict: string;
  data: object;
}) {
  return query(
    `INSERT INTO token_scores (token_address, chain, bardia_score, verdict, last_analyzed, data)
     VALUES ($1,$2,$3,$4,NOW(),$5)
     ON CONFLICT (token_address) DO UPDATE SET
       bardia_score = EXCLUDED.bardia_score,
       verdict = EXCLUDED.verdict,
       last_analyzed = NOW(),
       data = EXCLUDED.data,
       chain = EXCLUDED.chain
     RETURNING id`,
    [opts.tokenAddress, opts.chain, opts.score, opts.verdict, JSON.stringify(opts.data)]
  );
}

export async function getUserByEmail(email: string) {
  return queryOne<{
    id: number;
    email: string;
    username: string | null;
    password_hash: string;
    subscription_plan: string;
  }>('SELECT * FROM users WHERE email = $1', [email]);
}

export async function createUser(opts: {
  email: string;
  passwordHash: string;
  username?: string;
}) {
  return queryOne<{ id: number; email: string }>(
    `INSERT INTO users (email, password_hash, username)
     VALUES ($1,$2,$3) RETURNING id, email`,
    [opts.email, opts.passwordHash, opts.username ?? null]
  );
}

export async function getWatchlist(userId: number) {
  return query(
    'SELECT * FROM watchlists WHERE user_id = $1 ORDER BY added_at DESC',
    [userId]
  );
}

export async function addToWatchlist(opts: {
  userId: number;
  tokenAddress: string;
  chain: string;
  symbol?: string;
  name?: string;
}) {
  return query(
    `INSERT INTO watchlists (user_id, token_address, chain, symbol, name)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (user_id, token_address, chain) DO NOTHING
     RETURNING id`,
    [opts.userId, opts.tokenAddress, opts.chain, opts.symbol ?? null, opts.name ?? null]
  );
}
