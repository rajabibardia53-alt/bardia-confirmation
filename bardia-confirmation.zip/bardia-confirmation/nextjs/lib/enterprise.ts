/**
 * Enterprise Smart Money providers — Nansen / Arkham
 *
 * IMPORTANT:
 * Nansen and Arkham do NOT offer free public APIs.
 * Access requires a paid enterprise contract + API key.
 *
 * This module provides:
 * 1. Typed interfaces matching typical response shapes
 * 2. Client stubs that call your backend proxy (never expose keys in browser)
 * 3. Graceful fallback when keys are missing
 *
 * Backend routes expected:
 *   GET /api/smartmoney/nansen?address=&chain=
 *   GET /api/smartmoney/arkham?address=&chain=
 */

export type SmartMoneyFlow = {
  provider: 'nansen' | 'arkham' | 'heuristic';
  label: string;
  inflowUsd24h: number | null;
  outflowUsd24h: number | null;
  netFlowUsd24h: number | null;
  smartMoneyWallets: number | null;
  topWallets: {
    address: string;
    label?: string;
    balanceUsd?: number;
    change24hUsd?: number;
  }[];
  signal: 'accumulation' | 'distribution' | 'neutral';
  confidence: number; // 0-100
  note: string;
  rawAvailable: boolean;
};

export type EnterpriseConfig = {
  nansenConfigured: boolean;
  arkhamConfigured: boolean;
};

/** Check which enterprise providers are configured (server-side env) */
export function getEnterpriseConfig(): EnterpriseConfig {
  return {
    nansenConfigured: Boolean(process.env.NANSEN_API_KEY),
    arkhamConfigured: Boolean(process.env.ARKHAM_API_KEY),
  };
}

/**
 * Server-side: fetch Nansen smart money data.
 * Replace base URL / headers with your real Nansen contract docs.
 */
export async function fetchNansenServer(
  tokenAddress: string,
  chain: string
): Promise<SmartMoneyFlow | null> {
  const key = process.env.NANSEN_API_KEY;
  if (!key) return null;

  // Placeholder — wire to real Nansen endpoint once you have access.
  // Example pattern only:
  // const res = await fetch(`https://api.nansen.ai/v1/...`, {
  //   headers: { 'API-KEY': key, Accept: 'application/json' },
  // });
  console.info('[Nansen] key present — implement real endpoint for', chain, tokenAddress);
  return {
    provider: 'nansen',
    label: 'Nansen Smart Money',
    inflowUsd24h: null,
    outflowUsd24h: null,
    netFlowUsd24h: null,
    smartMoneyWallets: null,
    topWallets: [],
    signal: 'neutral',
    confidence: 0,
    note: 'Nansen API key detected. Wire the official endpoint in lib/enterprise.ts.',
    rawAvailable: false,
  };
}

/**
 * Server-side: fetch Arkham Intelligence data.
 */
export async function fetchArkhamServer(
  tokenAddress: string,
  chain: string
): Promise<SmartMoneyFlow | null> {
  const key = process.env.ARKHAM_API_KEY;
  if (!key) return null;

  // Placeholder — wire to real Arkham endpoint once you have access.
  console.info('[Arkham] key present — implement real endpoint for', chain, tokenAddress);
  return {
    provider: 'arkham',
    label: 'Arkham Intelligence',
    inflowUsd24h: null,
    outflowUsd24h: null,
    netFlowUsd24h: null,
    smartMoneyWallets: null,
    topWallets: [],
    signal: 'neutral',
    confidence: 0,
    note: 'Arkham API key detected. Wire the official endpoint in lib/enterprise.ts.',
    rawAvailable: false,
  };
}

/**
 * Client-side helper — calls your Next.js API routes (keys stay on server).
 */
export async function fetchSmartMoneyClient(
  address: string,
  chain: string
): Promise<{ nansen: SmartMoneyFlow | null; arkham: SmartMoneyFlow | null }> {
  try {
    const [nRes, aRes] = await Promise.all([
      fetch(`/api/smartmoney/nansen?address=${encodeURIComponent(address)}&chain=${encodeURIComponent(chain)}`),
      fetch(`/api/smartmoney/arkham?address=${encodeURIComponent(address)}&chain=${encodeURIComponent(chain)}`),
    ]);
    const nansen = nRes.ok ? await nRes.json() : null;
    const arkham = aRes.ok ? await aRes.json() : null;
    return { nansen, arkham };
  } catch {
    return { nansen: null, arkham: null };
  }
}
