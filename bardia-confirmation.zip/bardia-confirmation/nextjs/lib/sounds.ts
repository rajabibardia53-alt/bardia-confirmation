/**
 * Bardia Sound Engine v2 — Optimized Web Audio API
 */

export type SoundStep =
  | 'detect_chain' | 'fetch_market' | 'fetch_security' | 'fetch_holders'
  | 'fetch_whale' | 'fetch_social' | 'news_sentiment' | 'calculate_scores'
  | 'ai_analysis' | 'final_scoring' | 'generate_signals' | 'generate_report'
  | 'error' | 'success' | 'click' | 'notify';

type OscType = OscillatorType;

interface Voice {
  osc: OscillatorNode;
  gain: GainNode;
  stopAt: number;
}

class AnalysisSoundEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private dryGain: GainNode | null = null;
  private convolver: ConvolverNode | null = null;
  private reverbBus: GainNode | null = null;
  private enabled = true;
  private volume = 0.5;
  private unlocked = false;
  private voices: Voice[] = [];
  private maxVoices = 8;

  async unlock(): Promise<void> {
    this.ensureGraph();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') {
      try { await this.ctx.resume(); } catch { /* ignore */ }
    }
    this.unlocked = this.ctx.state === 'running';
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.master) this.master.gain.setTargetAtTime(this.volume, this.now(), 0.02);
  }

  toggle(on: boolean) {
    this.enabled = on;
    if (!on) this.killAll();
  }

  isEnabled() { return this.enabled; }

  private ensureGraph() {
    if (this.ctx) return;
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(this.ctx.destination);

    this.sfxBus = this.ctx.createGain();
    this.sfxBus.gain.value = 1;
    this.sfxBus.connect(this.master);

    this.dryGain = this.ctx.createGain();
    this.dryGain.gain.value = 0.85;
    this.dryGain.connect(this.sfxBus);

    this.convolver = this.ctx.createConvolver();
    this.convolver.buffer = this.makeImpulse(1.2, 2.0);
    this.reverbBus = this.ctx.createGain();
    this.reverbBus.gain.value = 0.18;
    this.convolver.connect(this.reverbBus);
    this.reverbBus.connect(this.sfxBus);
  }

  private now() { return this.ctx?.currentTime ?? 0; }

  private makeImpulse(duration: number, decay: number): AudioBuffer {
    const rate = this.ctx!.sampleRate;
    const len = Math.floor(rate * duration);
    const buf = this.ctx!.createBuffer(2, len, rate);
    for (let c = 0; c < 2; c++) {
      const data = buf.getChannelData(c);
      for (let i = 0; i < len; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
      }
    }
    return buf;
  }

  private pruneVoices() {
    const t = this.now();
    this.voices = this.voices.filter((v) => v.stopAt > t);
    while (this.voices.length >= this.maxVoices) {
      const oldest = this.voices.shift();
      try { oldest?.osc.stop(); } catch { /* */ }
    }
  }

  private killAll() {
    for (const v of this.voices) {
      try {
        v.gain.gain.cancelScheduledValues(this.now());
        v.gain.gain.setTargetAtTime(0.0001, this.now(), 0.01);
        v.osc.stop(this.now() + 0.05);
      } catch { /* */ }
    }
    this.voices = [];
  }

  private tone(opts: {
    freq: number; dur: number; type?: OscType; slideTo?: number;
    attack?: number; decay?: number; sustain?: number; release?: number;
    peak?: number; reverb?: boolean; delay?: number;
  }) {
    if (!this.enabled) return;
    this.ensureGraph();
    if (!this.ctx || !this.dryGain) return;
    if (!this.unlocked && this.ctx.state !== 'running') return;

    this.pruneVoices();
    const t0 = this.now() + (opts.delay ?? 0);
    const attack = opts.attack ?? 0.015;
    const decay = opts.decay ?? 0.06;
    const sustain = opts.sustain ?? 0.35;
    const release = opts.release ?? 0.12;
    const peak = opts.peak ?? 0.65;
    const dur = Math.max(opts.dur, attack + release);

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = opts.type ?? 'sine';
    osc.frequency.setValueAtTime(opts.freq, t0);
    if (opts.slideTo) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, opts.slideTo), t0 + dur);
    }

    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(peak, t0 + attack);
    gain.gain.linearRampToValueAtTime(peak * sustain, t0 + attack + decay);
    gain.gain.setValueAtTime(peak * sustain, t0 + dur - release);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    osc.connect(gain);
    gain.connect(this.dryGain);
    if (opts.reverb && this.convolver) {
      const send = this.ctx.createGain();
      send.gain.value = 0.4;
      gain.connect(send);
      send.connect(this.convolver);
    }

    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
    this.voices.push({ osc, gain, stopAt: t0 + dur + 0.05 });
  }

  play(step: SoundStep) {
    if (!this.enabled) return;
    switch (step) {
      case 'detect_chain':
        this.tone({ freq: 880, dur: 0.1, type: 'square', peak: 0.45, attack: 0.008 });
        this.tone({ freq: 1320, dur: 0.09, type: 'square', peak: 0.4, delay: 0.085 });
        break;
      case 'fetch_market':
        this.tone({ freq: 523.25, dur: 0.14, type: 'sine', peak: 0.5 });
        this.tone({ freq: 659.25, dur: 0.14, type: 'sine', peak: 0.45, delay: 0.11 });
        break;
      case 'fetch_security':
        this.tone({ freq: 196, dur: 0.2, type: 'triangle', peak: 0.55, reverb: true });
        this.tone({ freq: 294, dur: 0.16, type: 'triangle', peak: 0.4, delay: 0.13 });
        break;
      case 'fetch_holders':
        this.tone({ freq: 440, dur: 0.09, type: 'sine', peak: 0.4 });
        this.tone({ freq: 554, dur: 0.09, type: 'sine', peak: 0.38, delay: 0.07 });
        this.tone({ freq: 659, dur: 0.1, type: 'sine', peak: 0.35, delay: 0.14 });
        break;
      case 'fetch_whale':
        this.tone({ freq: 70, dur: 0.4, type: 'sine', slideTo: 48, peak: 0.7, attack: 0.04, release: 0.2, reverb: true });
        break;
      case 'fetch_social':
        this.tone({ freq: 720, dur: 0.07, type: 'square', peak: 0.35 });
        this.tone({ freq: 960, dur: 0.07, type: 'square', peak: 0.3, delay: 0.06 });
        break;
      case 'news_sentiment':
        this.tone({ freq: 620, dur: 0.11, type: 'triangle', peak: 0.45 });
        this.tone({ freq: 780, dur: 0.11, type: 'triangle', peak: 0.4, delay: 0.09 });
        break;
      case 'calculate_scores':
        this.tone({ freq: 400, dur: 0.07, type: 'sawtooth', peak: 0.3 });
        this.tone({ freq: 500, dur: 0.07, type: 'sawtooth', peak: 0.28, delay: 0.055 });
        this.tone({ freq: 620, dur: 0.08, type: 'sawtooth', peak: 0.26, delay: 0.11 });
        break;
      case 'ai_analysis':
        this.tone({ freq: 280, dur: 0.28, type: 'sine', slideTo: 560, peak: 0.5, reverb: true });
        this.tone({ freq: 560, dur: 0.22, type: 'sine', slideTo: 280, peak: 0.4, delay: 0.2, reverb: true });
        break;
      case 'final_scoring':
        this.tone({ freq: 523.25, dur: 0.14, type: 'sine', peak: 0.5 });
        this.tone({ freq: 659.25, dur: 0.14, type: 'sine', peak: 0.48, delay: 0.12 });
        this.tone({ freq: 783.99, dur: 0.18, type: 'sine', peak: 0.45, delay: 0.24 });
        break;
      case 'generate_signals':
        this.tone({ freq: 880, dur: 0.09, type: 'square', peak: 0.4 });
        this.tone({ freq: 1175, dur: 0.11, type: 'square', peak: 0.35, delay: 0.09 });
        break;
      case 'generate_report':
      case 'success':
        this.tone({ freq: 523.25, dur: 0.14, type: 'sine', peak: 0.5, reverb: true });
        this.tone({ freq: 659.25, dur: 0.14, type: 'sine', peak: 0.48, delay: 0.13, reverb: true });
        this.tone({ freq: 783.99, dur: 0.14, type: 'sine', peak: 0.46, delay: 0.26, reverb: true });
        this.tone({ freq: 1046.5, dur: 0.38, type: 'sine', peak: 0.55, delay: 0.4, release: 0.22, reverb: true });
        break;
      case 'error':
        this.tone({ freq: 180, dur: 0.28, type: 'sawtooth', slideTo: 110, peak: 0.55, attack: 0.01 });
        break;
      case 'click':
        this.tone({ freq: 1200, dur: 0.04, type: 'square', peak: 0.2, attack: 0.005 });
        break;
      case 'notify':
        this.tone({ freq: 880, dur: 0.08, type: 'sine', peak: 0.4 });
        this.tone({ freq: 1320, dur: 0.1, type: 'sine', peak: 0.35, delay: 0.08 });
        break;
    }
  }
}

export const soundEngine =
  typeof window !== 'undefined' ? new AnalysisSoundEngine() : null;
