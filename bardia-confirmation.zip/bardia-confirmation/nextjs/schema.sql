-- Bardia Confirmation — PostgreSQL schema
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  avatar_url TEXT,
  subscription_plan VARCHAR(50) DEFAULT 'free',
  risk_profile VARCHAR(20) DEFAULT 'moderate',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  address TEXT NOT NULL,
  chain VARCHAR(30) NOT NULL,
  label VARCHAR(100),
  is_primary BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS watchlists (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token_address TEXT NOT NULL,
  chain VARCHAR(30),
  symbol VARCHAR(30),
  name VARCHAR(100),
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, token_address, chain)
);

CREATE TABLE IF NOT EXISTS analysis_history (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  token_address TEXT NOT NULL,
  chain VARCHAR(30),
  final_score DECIMAL(5,2),
  verdict VARCHAR(30),
  full_report JSONB,
  preferred_llm VARCHAR(20),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analysis_token ON analysis_history(token_address);
CREATE INDEX IF NOT EXISTS idx_analysis_user ON analysis_history(user_id);

CREATE TABLE IF NOT EXISTS trades (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token_address TEXT,
  chain VARCHAR(30),
  side VARCHAR(10),
  amount NUMERIC,
  price NUMERIC,
  tx_hash TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS alerts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  token_address TEXT,
  alert_type VARCHAR(50),
  condition JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS news_cache (
  id SERIAL PRIMARY KEY,
  title TEXT,
  summary TEXT,
  source VARCHAR(100),
  url TEXT,
  related_tokens TEXT[],
  sentiment VARCHAR(20),
  published_at TIMESTAMPTZ,
  fetched_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS token_scores (
  id SERIAL PRIMARY KEY,
  token_address TEXT UNIQUE,
  chain VARCHAR(30),
  bardia_score DECIMAL(5,2),
  verdict VARCHAR(30),
  last_analyzed TIMESTAMPTZ,
  data JSONB
);

CREATE INDEX IF NOT EXISTS idx_token_scores_addr ON token_scores(token_address);
