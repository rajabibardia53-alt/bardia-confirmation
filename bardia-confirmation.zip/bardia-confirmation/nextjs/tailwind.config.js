/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        cyber: {
          black: '#05050a',
          navy: '#0a0e1a',
          dark: '#0f172a',
          blue: '#00d4ff',
          gold: '#ffd700',
          green: '#00ff9d',
          red: '#ff3366',
          purple: '#7c3aed',
        },
      },
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
      },
      boxShadow: {
        'neon-blue': '0 0 20px rgba(0, 212, 255, 0.3)',
        'neon-gold': '0 0 20px rgba(255, 215, 0, 0.3)',
      },
    },
  },
  plugins: [],
};
